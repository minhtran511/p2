import { Camera, Node, UITransform, Vec3 } from 'cc';
import { BeeBuzzing_BigHiveLayout, BeeBuzzing_SculptureLayout, BeeBuzzing_SlotLayout } from './BeeBuzzing.ControllerConfig';

export interface ILayoutContext {
    camera3D: Camera;
    uiCamera: Camera;
    sculpture: BeeBuzzing_SculptureLayout;
    slots: BeeBuzzing_SlotLayout;
    bigHive: BeeBuzzing_BigHiveLayout;
}

export class BeeBuzzing_Layout {
    constructor(private readonly ctx: ILayoutContext) {}

    public get slotCount(): number {
        return this.ctx.slots.layout ? this.ctx.slots.layout.children.length : 0;
    }

    public slotNode(i: number): Node | null {
        return this.ctx.slots.layout ? this.ctx.slots.layout.children[i] ?? null : null;
    }

    public uiToWorld(uiNode: Node, offsetX: number, offsetY: number, worldZ: number, out: Vec3 = new Vec3()): Vec3 {
        const tf = uiNode.getComponent(UITransform)!;
        const wp = tf.convertToWorldSpaceAR(new Vec3(offsetX, offsetY, 0));
        const sp = this.ctx.uiCamera.worldToScreen(wp);
        return this.ctx.camera3D.screenToWorld(new Vec3(sp.x, sp.y, this.depthOf(worldZ)), out);
    }

    public uiWidthInWorld(uiNode: Node, worldZ: number): number {
        const tf = uiNode.getComponent(UITransform)!;
        const a = this.uiToWorld(uiNode, -tf.width * tf.anchorX, 0, worldZ);
        const b = this.uiToWorld(uiNode, tf.width * (1 - tf.anchorX), 0, worldZ);
        return Vec3.distance(a, b);
    }

    public sculpturePos(out: Vec3 = new Vec3()): Vec3 {
        const s = this.ctx.sculpture;
        if (s.anchor) return this.uiToWorld(s.anchor, 0, 0, s.z, out);
        return out.set(0, 0.5, s.z);
    }

    public homePos(out: Vec3 = new Vec3()): Vec3 {
        const { bigHive, slots } = this.ctx;
        const z = slots.planeZ - bigHive.back;
        if (!bigHive.node) return out.set(0, 5, z);
        const tf = bigHive.node.getComponent(UITransform)!;
        const bottom = -tf.height * tf.anchorY;
        return this.uiToWorld(bigHive.node, 0, bottom + tf.height * bigHive.holeFromBottom, z, out);
    }

    public slotPos(i: number): Vec3 {
        const s = this.slotNode(i);
        return s ? this.uiToWorld(s, 0, 0, this.ctx.slots.planeZ) : new Vec3((i - 2) * 1.3, -3.5, this.ctx.slots.planeZ);
    }

    public linePos(line: number, index: number): Vec3 {
        const cfg = this.ctx.slots;
        const z = cfg.planeZ - cfg.queueRowGapZ * (index + 1);
        const s = this.slotNode(line);
        if (!s) return new Vec3((line - 2) * 1.3, -4.8 - index * 1.2, z);
        const dy = -cfg.queueRowGapPx * index;
        if (cfg.queueAnchor) {
            const n = this.slotCount;
            const sx = cfg.queueColGapPx > 0
                ? (line - (n - 1) / 2) * cfg.queueColGapPx
                : s.getWorldPosition().x - cfg.layout!.getWorldPosition().x;
            return this.uiToWorld(cfg.queueAnchor, sx, dy, z);
        }
        return this.uiToWorld(s, 0, dy - cfg.queueRowGapPx, z);
    }

    public hiveSize(): number {
        const s = this.slotNode(0);
        return s ? this.uiWidthInWorld(s, this.ctx.slots.planeZ) : 1.2;
    }

    public faceCamera(n: Node): void {
        const d = Vec3.subtract(new Vec3(), this.ctx.camera3D.node.worldPosition, n.worldPosition);
        const yaw = Math.atan2(d.x, d.z) * 180 / Math.PI;
        const pitch = -Math.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * 180 / Math.PI;
        n.setRotationFromEuler(pitch + this.ctx.slots.tiltDeg, yaw, 0);
    }

    public static upOf(n: Node): Vec3 {
        return Vec3.transformQuat(new Vec3(), Vec3.UP, n.worldRotation).normalize();
    }

    private depthOf(worldZ: number): number {
        const cam = this.ctx.camera3D;
        const viewDir = cam.node.forward.clone().normalize();
        const onPlane = new Vec3(cam.node.worldPosition.x, cam.node.worldPosition.y, worldZ);
        const d = Math.abs(Vec3.dot(onPlane.subtract(cam.node.worldPosition), viewDir));
        return (d - cam.near) / (cam.far - cam.near);
    }
}
