import { _decorator, Camera, JsonAsset, Node, Prefab } from 'cc';
import { BeeBuzzing_CubeGrid } from '../Grid/BeeBuzzing.CubeGrid';
const { ccclass, property } = _decorator;

@ccclass("BeeBuzzing_SceneRefs")
export class BeeBuzzing_SceneRefs {
    @property({ type: Camera, tooltip: "Camera3D Overlay (renders the UI_3D layer above the canvas)" })
    public camera3D: Camera | null = null;

    @property({ type: Camera, tooltip: "Camera 2D UI (used to map canvas nodes to screen space)" })
    public uiCamera: Camera | null = null;

    @property({ type: BeeBuzzing_CubeGrid })
    public grid: BeeBuzzing_CubeGrid | null = null;

    @property({ type: Node, tooltip: "Parent for spawned hives" })
    public hiveRoot: Node | null = null;

    @property({ type: Node, tooltip: "Parent for spawned bees" })
    public beeRoot: Node | null = null;

    @property({ type: Node, tooltip: "RenderRoot2D that holds every ammo label (one draw call)" })
    public labelRoot: Node | null = null;

    @property({ type: Node, tooltip: "Canvas sprite under the sculpture: turns with it, grows in the intro, shrinks as cubes are taken (0 when empty)" })
    public shadow: Node | null = null;
}

@ccclass("BeeBuzzing_AssetRefs")
export class BeeBuzzing_AssetRefs {
    @property({ type: JsonAsset, tooltip: "Raw level export (Marketing_teddy_burgundy.json)" })
    public level: JsonAsset | null = null;

    @property({ type: Prefab })
    public hivePrefab: Prefab | null = null;

    @property({ type: Prefab })
    public beePrefab: Prefab | null = null;
}

@ccclass("BeeBuzzing_SculptureLayout")
export class BeeBuzzing_SculptureLayout {
    @property({ type: Node, tooltip: "Canvas node marking the sculpture centre" })
    public anchor: Node | null = null;

    @property({ tooltip: "World z of the sculpture centre" })
    public z: number = 0;

    @property({ tooltip: "Overall size of the teddy (1 = level cell size). Written to CubeGrid.sculptureScale at start." })
    public scale: number = 0.8;

    @property({ range: [0.2, 1, 0.05], slide: true, tooltip: "Shadow footprint depth / width. The shadow's width follows the sculpture's yaw: full width when facing the camera, this ratio when seen from the side (1 = round, no change)." })
    public shadowDepthRatio: number = 0.6;
}

@ccclass("BeeBuzzing_SlotLayout")
export class BeeBuzzing_SlotLayout {
    @property({ type: Node, tooltip: "Canvas/Layout_Slot - its children are the slot pads" })
    public layout: Node | null = null;

    @property({ tooltip: "World z of the hive plane" })
    public planeZ: number = 0;

    @property({ range: [0.3, 1, 0.05], slide: true, tooltip: "Scale a hive shrinks to while flying into a slot (queue hives are always 1 = full pad width)" })
    public hiveWidthRatio: number = 0.8;

    @property({ tooltip: "Tilt in degrees on top of the camera-facing: <0 leans the hive top toward the camera (seen from behind), >0 leans it away" })
    public tiltDeg: number = -25;

    @property({ tooltip: "Queue rows shown under the slot row (the slot row itself is fixed to the Layout_Slot pads)" })
    public visibleQueue: number = 3;

    @property({ type: Node, tooltip: "Canvas node whose centre is the centre of the FIRST queue row (Anchor_Queue); rows below are queueRowGapPx apart, columns keep the slot pads' spacing" })
    public queueAnchor: Node | null = null;

    @property({ tooltip: "Distance from one queue row to the next, in canvas px (row 2 = row 1 - gap, ...)" })
    public queueRowGapPx: number = 230;

    @property({ tooltip: "Distance between queue columns, in canvas px, centred on the anchor (0 = same spacing as the slot pads)" })
    public queueColGapPx: number = 200;

    @property({ tooltip: "Each queue row is pushed this far back (-z) behind the slot plane, world units" })
    public queueRowGapZ: number = 0;

    @property({ range: [0, 1, 0.05], slide: true, tooltip: "Opacity of the waiting hives (the front hive of each line is 1 = opaque)" })
    public queueOpacity: number = 0.6;
}

@ccclass("BeeBuzzing_BigHiveLayout")
export class BeeBuzzing_BigHiveLayout {
    @property({ type: Node, tooltip: "Canvas node of the big hive (bees fly home to its hole)" })
    public node: Node | null = null;

    @property({ tooltip: "How far behind the hive plane the hole sits (bees shrink by perspective)" })
    public back: number = 7;

    @property({ tooltip: "Hole position from the sprite bottom, as a fraction of its height" })
    public holeFromBottom: number = 0.08;
}

@ccclass("BeeBuzzing_IntroConfig")
export class BeeBuzzing_IntroConfig {
    @property({ tooltip: "Grow the sculpture from the bottom row up before the game starts" })
    public enabled: boolean = true;

    @property({ tooltip: "Seconds to wait before the cubes start appearing" })
    public delay: number = 0.05;

    @property({ tooltip: "Seconds for the whole sculpture to appear (bottom -> top). Lower = faster." })
    public duration: number = 1.2;
}

@ccclass("BeeBuzzing_GameplayConfig")
export class BeeBuzzing_GameplayConfig {
    @property({ tooltip: "Seconds between two shots of one hive" })
    public fireInterval: number = 0.22;

    @property({ tooltip: "Seconds of 'nobody can shoot' before it counts as a loss (player may still rotate)" })
    public stuckGrace: number = 2.5;
}

@ccclass("BeeBuzzing_BeeConfig")
export class BeeBuzzing_BeeConfig {
    @property({ tooltip: "Bee body length in world units" })
    public size: number = 0.4;

    @property({ tooltip: "Cruise speed, world units/s (duration = path length / speed)" })
    public flySpeed: number = 6;

    @property({ tooltip: "Seconds the bee rests on the cube face before pulling it out" })
    public holdTime: number = 0.25;

    @property({ range: [1, 4, 0.1], slide: true, tooltip: "Depth fake: how much BIGGER the bee is when it leaves the hive (it shrinks back to normal size while flying off)" })
    public nearScale: number = 1.5;

    @property({ tooltip: "Seconds the bee takes to shrink from nearScale down to its normal size after leaving the hive" })
    public shrinkTime: number = 0.55;

    @property({ tooltip: "Orbit radius while the player rotates the sculpture = sculpture bounding radius + this (world units)" })
    public orbitPad: number = 0.9;

    @property({ tooltip: "Flight arcs keep at least this far outside the sculpture's bounding sphere (world units)" })
    public avoidMargin: number = 0.7;

    @property({ tooltip: "How far to the left/right the arcs swing, as a multiplier of the default swing" })
    public swingScale: number = 1;
}
