import { _decorator, Component, Node, Vec3, instantiate, input, Input, EventTouch, MeshRenderer, view, screen, Quat } from 'cc';
import { BeeBuzzing_Data, ILevelData, IRawLevel } from '../../Common/BeeBuzzing.Data';
import { BeeBuzzing_Event, EBeeBuzzing_Event } from '../../Common/BeeBuzzing.Event';
import { BeeBuzzing_CubeGrid } from '../Grid/BeeBuzzing.CubeGrid';
import { ICube } from '../Grid/BeeBuzzing.GridTypes';
import { BeeBuzzing_Hive, EHiveState } from '../Hive/BeeBuzzing.Hive';
import { BeeBuzzing_Bee } from '../Bee/BeeBuzzing.Bee';
import { IFlightOpts } from '../Bee/BeeBuzzing.BeeTypes';
import { BeeBuzzing_Tint } from '../Render/BeeBuzzing.Tint';
import { BeeBuzzing_Layout } from './BeeBuzzing.Layout';
import { BeeBuzzing_BeePool } from '../Optimize/BeeBuzzing.BeePool';
import { BeeBuzzing_SearchBudget } from '../Optimize/BeeBuzzing.SearchBudget';
import { Injection } from 'db://assets/Scripts/Core/Base/Module/Handler/Module.Dependency';
import { EModuleService } from 'db://assets/Scripts/Core/Base/Module/Common/Module.Enum';
import { BeeBuzzing_PlayableConfig } from '../../../BeeBuzzing.PlayableConfig';
import { BeeBuzzing_Audio, EBeeBuzzing_SFX } from '../../Systems/BeeBuzzing.Audio';
import {
    BeeBuzzing_AssetRefs, BeeBuzzing_BeeConfig, BeeBuzzing_BigHiveLayout, BeeBuzzing_GameplayConfig,
    BeeBuzzing_IntroConfig, BeeBuzzing_SceneRefs, BeeBuzzing_SculptureLayout, BeeBuzzing_SlotLayout,
} from './BeeBuzzing.ControllerConfig';
const { ccclass, property } = _decorator;

const HOP_TO_SLOT = 0.35;
const HOP_IN_QUEUE = 0.3;
const LAYOUT_SETTLE_TIME = 0.5;
const BUZZ_CLIPS: EBeeBuzzing_SFX[] = [EBeeBuzzing_SFX.BEE1, EBeeBuzzing_SFX.BEE2, EBeeBuzzing_SFX.BEE3];
const BUZZ_INTERVAL = 3;

@ccclass('BeeBuzzing_Controller')
export class BeeBuzzing_Controller extends Component {
    @property({ type: BeeBuzzing_SceneRefs, group: "Scene" })
    public scene: BeeBuzzing_SceneRefs = new BeeBuzzing_SceneRefs();

    @property({ type: BeeBuzzing_AssetRefs, group: "Assets" })
    public assets: BeeBuzzing_AssetRefs = new BeeBuzzing_AssetRefs();

    @property({ type: BeeBuzzing_SculptureLayout, group: "Layout" })
    public sculpture: BeeBuzzing_SculptureLayout = new BeeBuzzing_SculptureLayout();

    @property({ type: BeeBuzzing_SlotLayout, group: "Layout" })
    public slots: BeeBuzzing_SlotLayout = new BeeBuzzing_SlotLayout();

    @property({ type: BeeBuzzing_BigHiveLayout, group: "Layout" })
    public bigHive: BeeBuzzing_BigHiveLayout = new BeeBuzzing_BigHiveLayout();

    @property({ type: BeeBuzzing_IntroConfig, group: "Gameplay" })
    public intro: BeeBuzzing_IntroConfig = new BeeBuzzing_IntroConfig();

    @property({ type: BeeBuzzing_GameplayConfig, group: "Gameplay" })
    public gameplay: BeeBuzzing_GameplayConfig = new BeeBuzzing_GameplayConfig();

    @property({ type: BeeBuzzing_BeeConfig, group: "Gameplay" })
    public bee: BeeBuzzing_BeeConfig = new BeeBuzzing_BeeConfig();

    @Injection(BeeBuzzing_PlayableConfig.code, EModuleService.Audio)
    private _audio: BeeBuzzing_Audio = null!;

    private readonly searchBudget: BeeBuzzing_SearchBudget = new BeeBuzzing_SearchBudget();
    private readonly hives: BeeBuzzing_Hive[] = [];
    private readonly homePt: Vec3 = new Vec3();
    private readonly shadowScale: Vec3 = new Vec3(1, 1, 1);
    private layout: BeeBuzzing_Layout | null = null;
    private pool: BeeBuzzing_BeePool | null = null;
    private hiveTint: BeeBuzzing_Tint | null = null;
    private slotHives: (BeeBuzzing_Hive | null)[] = [];
    private lines: BeeBuzzing_Hive[][] = [];
    private fireTimers: number[] = [];
    private beesInFlight: number = 0;
    private speed: number = 1;
    private over: boolean = false;
    private started: boolean = false;
    private introDone: boolean = false;
    private ready: boolean = false;
    private stuckTime: number = 0;
    private settleTime: number = LAYOUT_SETTLE_TIME;
    private total: number = 0;
    private beeScale: number = 1;
    private beeTail: number = 0.3;
    private buzzTimer: number = 0;
    private buzzBag: EBeeBuzzing_SFX[] = [];
    private lastBuzz: EBeeBuzzing_SFX | null = null;

    private get grid(): BeeBuzzing_CubeGrid {
        return this.scene.grid!;
    }

    protected start(): void {
        if (!this.assets.level || !this.assets.hivePrefab || !this.assets.beePrefab || !this.scene.grid || !this.scene.camera3D || !this.scene.uiCamera) {
            console.error('[BeeBuzzing] Controller: missing references');
            return;
        }
        this.layout = new BeeBuzzing_Layout({ camera3D: this.scene.camera3D, uiCamera: this.scene.uiCamera, sculpture: this.sculpture, slots: this.slots, bigHive: this.bigHive });
        this.pool = new BeeBuzzing_BeePool(this.assets.beePrefab, this.scene.beeRoot || this.node);
        const data = BeeBuzzing_Data.parseLevel(this.assets.level.json as IRawLevel, Math.max(1, this.layout.slotCount || 5));
        this.slotHives = new Array(data.slotCount).fill(null);
        this.fireTimers = new Array(data.slotCount).fill(0);
        this.lines = [];
        for (let i = 0; i < data.lineCount; i++) this.lines.push([]);
        if (this.scene.shadow) this.scene.shadow.active = false;
        this.buildGrid(data);
        this.buildHives(data);
        this.measureBee();
        this.finishSetup();
        BeeBuzzing_Event.emit(EBeeBuzzing_Event.SETUP_DONE);
    }

    protected update(dt: number): void {
        if (!this.ready) return;
        this.updateShadow();
        if (this.settleTime > 0) {
            this.settleTime -= dt;
            this.applyLayout();
        }
        if (this.over) return;
        for (const h of this.hives) if (h.isValid) h.syncLabel();
        this.updateBuzz(dt);
        const anyCanFire = this.updateSlots(dt * this.speed);
        this.updateEndConditions(dt, anyCanFire);
    }

    protected onDestroy(): void {
        input.off(Input.EventType.TOUCH_START, this.onTap, this);
        view.off('canvas-resize', this.onResize, this);
        view.off('design-resolution-changed', this.onResize, this);
        screen.off('window-resize', this.onResize, this);
        screen.off('orientation-change', this.onResize, this);
        BeeBuzzing_Event.targetOff(this);
    }

    protected onResize(): void {
        this.scheduleOnce(() => this.applyLayout(), 0);
    }

    protected onSpeedChanged(x2: boolean): void {
        this.speed = x2 ? 2 : 1;
    }

    protected onTap(e: EventTouch): void {
        if (this.over || !this.introDone) return;
        const best = this.hitHive(e.getLocation());
        if (!best) return;
        this._audio.playOneShotSFX(EBeeBuzzing_SFX.CLICK);
        const free = this.slotHives.indexOf(null);
        if (free < 0 || this.lines[best.line][0] !== best) {
            best.punch();
            return;
        }

        this.activate(best, free);
    }

    protected onIntroComplete(): void {
    }

    private buildGrid(data: ILevelData): void {
        const g = this.grid;
        g.setCamera(this.scene.camera3D!);
        g.sculptureScale = this.sculpture.scale;
        g.build(data, this.intro.enabled);
        this.total = g.remaining;
        BeeBuzzing_Event.emit(EBeeBuzzing_Event.PROGRESS, 0, this.total);
        g.warmCubeMaterial();
    }

    private buildHives(data: ILevelData): void {
        const size = this.layout!.hiveSize();
        for (const h of data.hives) {
            const n = instantiate(this.assets.hivePrefab!);
            n.name = 'Hive_' + h.c;
            const hive = n.getComponent(BeeBuzzing_Hive)!;
            if (!this.hiveTint && hive.model) {
                const base = hive.model.getComponentInChildren(MeshRenderer)?.sharedMaterial;
                if (base) this.hiveTint = new BeeBuzzing_Tint(base);
            }
            hive.prepare(h.c, this.hiveTint);
            n.active = this.hives.length === 0;
            n.setParent(this.scene.hiveRoot || this.node);
            hive.init(h.c, h.ammo, h.line, h.index, this.hiveTint, size, this.scene.labelRoot);
            this.hives.push(hive);
            this.lines[h.line].push(hive);
        }
        for (const l of this.lines) l.sort((a, b) => a.index - b.index);
        for (const line of this.lines) {
            this.dimLine(line);
            line.forEach((q, i) => {
                q.node.active = i < this.slots.visibleQueue;
                q.node.setWorldPosition(this.layout!.linePos(q.line, i));
                this.layout!.faceCamera(q.node);
            });
        }
    }

    private measureBee(): void {
        const b = this.pool!.acquire();
        const m = this.pool!.measure(b, this.bee.size);
        this.beeScale = m.scale;
        this.beeTail = m.tail;
        b.setScale(0.001, 0.001, 0.001);
        b.setWorldPosition(this.homePt);
        this.scheduleOnce(() => this.pool!.release(b), 0.12);
    }

    private finishSetup(): void {
        this.ready = true;
        if (this.scene.shadow) {
            this.shadowScale.set(this.scene.shadow.scale);
            this.updateShadow();
        }
        this.applyLayout();
        input.on(Input.EventType.TOUCH_START, this.onTap, this);
        view.on('canvas-resize', this.onResize, this);
        view.on('design-resolution-changed', this.onResize, this);
        screen.on('window-resize', this.onResize, this);
        screen.on('orientation-change', this.onResize, this);
        BeeBuzzing_Event.on(EBeeBuzzing_Event.SPEED_CHANGED, this.onSpeedChanged, this);
        this.playIntro();
    }

    private playIntro(): void {
        if (!this.intro.enabled) {
            this.finishIntro();
            return;
        }
        this.scheduleOnce(() => this.grid.playIntro(this.intro.duration, () => this.finishIntro()), Math.max(0, this.intro.delay));
    }

    private finishIntro(): void {
        if (this.introDone) return;
        this.introDone = true;
        BeeBuzzing_Event.emit(EBeeBuzzing_Event.INTRO_DONE, this.guideHive());
        this.onIntroComplete();
    }

    private guideHive(): Node | null {
        const mid = Math.floor(this.lines.length / 2);
        const order = [mid, ...this.lines.map((_, i) => i).filter((i) => i !== mid)];
        for (const i of order) {
            const h = this.lines[i][0];
            if (h && h.node.activeInHierarchy) return h.node;
        }
        return null;
    }

    private applyLayout(): void {
        const lay = this.layout!;
        this.grid.node.setWorldPosition(lay.sculpturePos());
        lay.homePos(this.homePt);
        const size = lay.hiveSize();
        for (const h of this.hives) {
            if (!h.isValid || h.state === EHiveState.Done) continue;
            h.setSize(size);
            if (h.state !== EHiveState.Moving) {
                const k = h.slot >= 0 ? this.slots.hiveWidthRatio : 1;
                h.node.setScale(k, k, k);
            }
            if (h.slot >= 0) {
                h.node.setWorldPosition(lay.slotPos(h.slot));
            } else {
                const idx = this.lines[h.line].indexOf(h);
                if (idx >= 0) {
                    h.node.active = idx < this.slots.visibleQueue;
                    h.node.setWorldPosition(lay.linePos(h.line, idx));
                }
            }
            lay.faceCamera(h.node);
        }
    }

    private updateShadow(): void {
        const sh = this.scene.shadow;
        if (!sh) return;
        const g = this.grid;
        const f = (this.total > 0 ? g.remaining / this.total : 0) * g.revealProgress;
        sh.active = f > 0.001;
        const a = g.yaw * Math.PI / 180, r = this.sculpture.shadowDepthRatio;
        const c = Math.cos(a), s = Math.sin(a);
        sh.setScale(this.shadowScale.x * f * Math.sqrt(c * c + r * r * s * s), this.shadowScale.y * f, 1);
    }

    private updateSlots(sdt: number): boolean {
        let anyCanFire = false;
        this.searchBudget.reset();
        for (let i = 0; i < this.slotHives.length; i++) {
            const h = this.slotHives[i];
            if (!h || h.state !== EHiveState.Active) {
                if (h) anyCanFire = true;
                continue;
            }
            if (h.ammo <= 0) {
                this.retire(h);
                continue;
            }
            if (!this.grid.hasColor(h.color)) continue;
            if (this.grid.isDragging) { anyCanFire = true; continue; }
            this.fireTimers[i] -= sdt;
            if (this.fireTimers[i] > 0) { anyCanFire = true; continue; }
            if (!this.searchBudget.tryConsume()) { anyCanFire = true; continue; }
            const target = this.grid.findTarget(h.color);
            if (!target) continue;
            anyCanFire = true;
            this.fireTimers[i] = this.gameplay.fireInterval;
            this.fire(h, target.cube, target.exit);
        }
        return anyCanFire;
    }

    private updateEndConditions(dt: number, anyCanFire: boolean): void {
        const full = this.slotHives.every((s) => s !== null);
        const queueEmpty = this.lines.every((l) => l.length === 0);
        if ((full || queueEmpty) && !anyCanFire && this.beesInFlight === 0) {
            this.stuckTime += dt;
            if (this.stuckTime > this.gameplay.stuckGrace) this.finish(false);
        } else {
            this.stuckTime = 0;
        }
        if (this.grid.remaining === 0 && this.beesInFlight === 0) this.finish(true);
    }

    private hitHive(t: { x: number; y: number }): BeeBuzzing_Hive | null {
        const cam = this.scene.camera3D!;
        const camRight = Vec3.transformQuat(new Vec3(), Vec3.RIGHT, cam.node.worldRotation);
        let best: BeeBuzzing_Hive | null = null;
        let bestD = Infinity;
        for (const line of this.lines) {
            for (const h of line) {
                if (h.state !== EHiveState.Queue || !h.node.activeInHierarchy) continue;
                const sp = cam.worldToScreen(h.node.worldPosition);
                const edge = cam.worldToScreen(Vec3.scaleAndAdd(new Vec3(), h.node.worldPosition, camRight, h.size * h.node.scale.x * 0.5));
                const rPix = Math.abs(edge.x - sp.x) * 1.05;
                const d = (sp.x - t.x) ** 2 + (sp.y - t.y) ** 2;
                if (d <= rPix * rPix && d < bestD) { bestD = d; best = h; }
            }
        }
        return best;
    }

    private dimLine(line: BeeBuzzing_Hive[]): void {
        line.forEach((q, i) => q.setOpacity(i === 0 ? 1 : this.slots.queueOpacity));
    }

    private activate(h: BeeBuzzing_Hive, slot: number): void {
        const lay = this.layout!;
        const line = this.lines[h.line];
        line.shift();
        this.slotHives[slot] = h;
        h.slot = slot;
        h.setOpacity(1);
        this.dimLine(line);
        h.hopTo(lay.slotPos(slot), HOP_TO_SLOT / this.speed, () => {
            h.state = EHiveState.Active;
            this.fireTimers[slot] = (slot / Math.max(1, this.slotHives.length)) * this.gameplay.fireInterval;
            lay.faceCamera(h.node);
        }, this.slots.hiveWidthRatio, true);
        line.forEach((q, i) => {
            q.node.active = i < this.slots.visibleQueue;
            if (!q.node.active) q.node.setWorldPosition(lay.linePos(q.line, i));
        });
        line.forEach((q, i) => {
            if (!q.node.active) return;
            q.hopTo(lay.linePos(q.line, i), HOP_IN_QUEUE / this.speed, () => { q.state = EHiveState.Queue; lay.faceCamera(q.node); });
        });
        if (this.started) return;
        this.started = true;
        BeeBuzzing_Event.emit(EBeeBuzzing_Event.GAME_STARTED);
    }

    private retire(h: BeeBuzzing_Hive): void {
        this.slotHives[h.slot] = null;
        h.slot = -1;
        h.leave(() => { });
    }

    private launchSideFor(h: BeeBuzzing_Hive): number {
        const active = this.slotHives.filter((x): x is BeeBuzzing_Hive => !!x).sort((a, b) => a.slot - b.slot);
        if (active.length <= 2) return 0;
        if (active.length === 3) return active.indexOf(h) === 0 ? -1 : 1;
        const mid = (this.slotHives.length - 1) / 2;
        return h.slot < mid ? -1 : h.slot > mid ? 1 : 0;
    }

    private fire(h: BeeBuzzing_Hive, cube: ICube, exit: Vec3): void {
        if (!h.consume()) return;
        const g = this.grid;
        const pool = this.pool!;
        cube.reserved = true;
        const bee = pool.acquire();
        const fwd = BeeBuzzing_Layout.upOf(h.node);
        const spawnScale = this.beeScale * this.bee.nearScale;
        bee.setWorldPosition(Vec3.scaleAndAdd(new Vec3(), h.node.worldPosition, fwd, h.size * 0.5));
        bee.setScale(spawnScale, spawnScale, spawnScale);
        pool.tintBody(bee, h.color);
        this.beesInFlight++;

        let curCube = cube;
        let curNode = g.detach(cube);
        let exitLocal = this.toGridDir(exit);
        const exitWorld = (): Vec3 => Vec3.transformQuat(new Vec3(), exitLocal, g.node.worldRotation).normalize();
        const retarget = (): Node => {
            const toCam = Vec3.subtract(new Vec3(), this.scene.camera3D!.node.worldPosition, g.node.worldPosition).normalize();
            if (Vec3.dot(exitWorld(), toCam) > 0.2) return curNode;
            const t = g.findTarget(h.color);
            if (!t) {
                const r = g.escapeDir(curCube);
                if (r) exitLocal = this.toGridDir(r.dir);
                return curNode;
            }
            g.restore(curCube);
            curCube = t.cube;
            curCube.reserved = true;
            curNode = g.detach(curCube);
            exitLocal = this.toGridDir(t.exit);
            return curNode;
        };
        const opts: IFlightOpts = {
            jitter: new Vec3((Math.random() - 0.5) * 0.5, (Math.random() - 0.5) * 0.4, (Math.random() - 0.5) * 0.4),
            tailLen: this.beeTail,
            flySpeed: this.bee.flySpeed,
            holdTime: this.bee.holdTime,
            hiveForward: fwd,
            sculptCenter: g.node.worldPosition.clone(),
            sculptRadius: g.radius,
            cubeHalf: g.cellSize * this.sculpture.scale * 0.5,
            launchSide: this.launchSideFor(h),
            scaleFrom: spawnScale,
            scaleTo: this.beeScale,
            scaleTime: this.bee.shrinkTime,
            orbitPad: this.bee.orbitPad,
            avoidMargin: this.bee.avoidMargin,
            swingScale: this.bee.swingScale,
            cubeWorld: () => curNode.worldPosition.clone(),
            exitWorld,
            isDragging: () => g.isDragging,
            toLocal: (p: Vec3) => Vec3.transformMat4(new Vec3(), p, g.node.worldMatrix.clone().invert()),
            toWorld: (p: Vec3) => Vec3.transformMat4(new Vec3(), p, g.node.worldMatrix),
            retarget,
        };
        bee.getComponent(BeeBuzzing_Bee)!.fly(curNode, this.speed, () => this.homePt, opts,
            () => {
                g.take(curCube);
                BeeBuzzing_Event.emit(EBeeBuzzing_Event.PROGRESS, this.total - g.remaining, this.total);
            },
            () => {
                this.beesInFlight--;
                curNode.destroy();
                pool.release(bee);
                if (this.beesInFlight === 0) this.stopBuzz();
            });
    }

    private updateBuzz(dt: number): void {
        if (this.beesInFlight <= 0 || !this._audio) return;
        this.buzzTimer -= dt;
        if (this.buzzTimer > 0) return;
        this.buzzTimer = BUZZ_INTERVAL;
        if (this.buzzBag.length === 0) {
            this.buzzBag = BUZZ_CLIPS.slice().sort(() => Math.random() - 0.5);
            if (this.buzzBag[this.buzzBag.length - 1] === this.lastBuzz) this.buzzBag.reverse();
        }
        this.lastBuzz = this.buzzBag.pop()!;
        this._audio.playSFXById(this.lastBuzz);
    }

    private stopBuzz(): void {
        this.buzzTimer = 0;
        if (!this._audio) return;
        for (const id of BUZZ_CLIPS) {
            const source = this._audio.getAudioSourceSFX(id);
            if (source && source.playing) source.stop();
        }
    }

    private toGridDir(worldDir: Vec3): Vec3 {
        return Vec3.transformQuat(new Vec3(), worldDir, Quat.invert(new Quat(), this.grid.node.worldRotation)).normalize();
    }

    private finish(win: boolean): void {
        if (this.over) return;
        this.over = true;
        this.stopBuzz();
        if (this._audio) this._audio.playOneShotSFX(win ? EBeeBuzzing_SFX.VICTORY : EBeeBuzzing_SFX.FAIL);
        BeeBuzzing_Event.emit(win ? EBeeBuzzing_Event.WIN : EBeeBuzzing_Event.LOSE);
    }
}
