import { Node, Vec3 } from 'cc';

export interface ICube {
    key: number;
    x: number;
    y: number;
    z: number;
    color: number;
    local: Vec3;
    node: Node | null;
    chunk: number;
    reserved: boolean;
    removed: boolean;
}

export interface IEscape {
    dir: Vec3;
    steps: number;
}

export interface ITarget {
    cube: ICube;
    exit: Vec3;
}
