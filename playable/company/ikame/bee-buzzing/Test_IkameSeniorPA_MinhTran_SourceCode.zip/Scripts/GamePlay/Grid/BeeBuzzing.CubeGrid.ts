import { _decorator, Component, Node, Mesh, MeshRenderer, Material, Vec3, Vec4, Camera, Quat, EventTouch, math, tween } from 'cc';
import { ILevelData } from '../../Common/BeeBuzzing.Data';
import { BeeBuzzing_Config } from '../../Common/BeeBuzzing.Config';
import { BeeBuzzing_Tint } from '../Render/BeeBuzzing.Tint';
import { ICube, IEscape, ITarget } from './BeeBuzzing.GridTypes';
import { BeeBuzzing_ChunkMesh } from '../Optimize/BeeBuzzing.ChunkMesh';
import { BeeBuzzing_RebuildBudget } from '../Optimize/BeeBuzzing.RebuildBudget';
import { BeeBuzzing_MaterialWarmup } from '../Optimize/BeeBuzzing.MaterialWarmup';
import { BeeBuzzing_PathFinder, IPathGrid } from './BeeBuzzing.PathFinder';
import { Injection } from 'db://assets/Scripts/Core/Base/Module/Handler/Module.Dependency';
import { BeeBuzzing_PlayableConfig } from '../../../BeeBuzzing.PlayableConfig';
import { BeeBuzzing_Audio } from '../../Systems/BeeBuzzing.Audio';
import { EModuleService } from 'db://assets/Scripts/Core/Base/Module/Common/Module.Enum';
import { ScreenService } from 'db://assets/Scripts/Core/Base/Services/Screen/Screen.Service';
const { ccclass, property } = _decorator;

const DIRS = BeeBuzzing_Config.DIRS;
const DRAG_DEAD_ZONE_SQ = 36;

@ccclass('BeeBuzzing_CubeGrid')
export class BeeBuzzing_CubeGrid extends Component implements IPathGrid {
    @property({ type: Node, tooltip: 'Canvas node whose rect receives the rotate-drag' })
    public touchUI: Node | null = null;

    @property(Mesh)
    public cubeMesh: Mesh | null = null;

    @property(Material)
    public cubeMaterial: Material | null = null;

    @property({ tooltip: 'Overall size of the sculpture (1 = level cell size).' })
    public sculptureScale: number = 1;

    @property({ range: [-0.15, 0.2, 0.005], slide: true, tooltip: 'Gap between neighbouring cubes as a fraction of the cell (0 = touching; negative = overlap, hides the bevel seams of the cube mesh).' })
    public cubeGap: number = -0.06;

    @property({ tooltip: 'Merge still cubes into chunk meshes (fewer nodes, less CPU). Off = one node per cube.' })
    public mergeMeshes: boolean = true;

    @property({ tooltip: 'Number of merged chunks (vertical bands). More chunks = cheaper rebuilds, more draw calls.' })
    public chunks: number = 6;

    @property({ tooltip: 'Max merged chunks rebuilt per frame during play (a rebuild costs ~3-10 ms; with many bees grabbing at once this keeps the frame time flat).' })
    public maxRebuildsPerFrame: number = 1;

    @property({ tooltip: 'Idle auto-rotation, deg/s (starts after the intro)' })
    public idleSpin: number = 8;

    @property({ tooltip: 'Spin from right to left instead of left to right' })
    public spinRightToLeft: boolean = false;

    @property({ tooltip: 'Initial yaw (deg) so the sculpture faces the player (0 = as authored in the level)' })
    public startYaw: number = 180;

    @property({ tooltip: 'Initial pitch (deg) of the sculpture' })
    public startPitch: number = 0;

    @property({ tooltip: 'Intro: each cube grows 0 -> 1 while the reveal front climbs this many rows past it' })
    public introGrowRows: number = 3;

    @property({ tooltip: '90-degree bends allowed on a bee\'s escape path' })
    public maxTurns: number = 2;

    @property({ tooltip: 'Escape path search stops after this many cells (deeper cubes are simply not shootable yet). Keeps the BFS cheap.' })
    public maxPathSteps: number = 10;

    @property({ tooltip: 'Rotation speed while dragging, degrees per pixel' })
    public dragSpeed: number = 0.35;

    @property({ tooltip: 'How many top-ranked candidates get a full path check per shot (outer cubes win ties).' })
    public pathCandidates: number = 12;

    @property({ tooltip: 'Skip fully enclosed cubes when building the meshes (they appear as soon as a neighbour is removed). Cuts triangles and hides the interior.' })
    public hideBuried: boolean = true;

    @Injection(BeeBuzzing_PlayableConfig.code, EModuleService.Audio)
    private _audio: BeeBuzzing_Audio = null!;
    
    private readonly cubes: Map<number, ICube> = new Map<number, ICube>();
    private readonly origin: Vec3 = new Vec3();
    private readonly rot: Quat = new Quat();
    private readonly chunkNodes: Node[] = [];
    private readonly rebuildBudget: BeeBuzzing_RebuildBudget = new BeeBuzzing_RebuildBudget();
    private readonly pathFinder: BeeBuzzing_PathFinder = new BeeBuzzing_PathFinder(this);
    private size: { x: number; y: number; z: number } = { x: 0, y: 0, z: 0 };
    private cell: number = 1;
    private cam: Camera | null = null;
    private dragging: boolean = false;
    private armed: boolean = false;
    private velX: number = 0;
    private velY: number = 0;
    private extentY: number = 1;
    private boundRadius: number = 1;
    private meshScale: number = 1;
    private minY: number = 0;
    private maxY: number = 0;
    private revealY: number = 1e9;
    private spinning: boolean = true;
    private chunkMesh: BeeBuzzing_ChunkMesh | null = null;
    private chunkMaterial: Material | null = null;
    private tinted: BeeBuzzing_Tint | null = null;

    public get remaining(): number { return this.cubes.size; }
    public get isDragging(): boolean { return this.dragging && this.armed; }
    public get cellSize(): number { return this.cell; }
    public get height(): number { return this.extentY * this.sculptureScale; }
    public get radius(): number { return this.boundRadius * this.sculptureScale; }
    public get introDone(): boolean { return this.revealY >= this.maxY + this.introGrowRows; }
    public get yaw(): number { return this.node.eulerAngles.y; }
    public get camera(): Camera | null { return this.cam; }
    public get gridSize(): { x: number; y: number; z: number } { return this.size; }
    public get center(): Vec3 { return this.node.worldPosition; }

    public get revealProgress(): number {
        if (this.revealY >= 1e8) return 1;
        return Math.max(0, Math.min(1, (this.revealY - this.minY + 1) / (this.maxY - this.minY + 1 + this.introGrowRows)));
    }

    public setCamera(c: Camera): void {
        this.cam = c;
    }

    public build(level: ILevelData, startHidden: boolean = false): void {
        this.node.layer = BeeBuzzing_Config.LAYER_3D;
        this.size = level.gridSize;
        this.cell = level.cellSize;
        this.measureBounds(level);
        if (this.cubeMesh) {
            const mn = this.cubeMesh.struct.minPosition, mx = this.cubeMesh.struct.maxPosition;
            if (mn && mx) this.meshScale = this.cell / Math.max(mx.x - mn.x, mx.y - mn.y, mx.z - mn.z) * (1 - this.cubeGap);
        }
        Quat.fromEuler(this.rot, this.startPitch, this.startYaw, 0);
        this.node.setRotation(this.rot);
        this.node.setScale(this.sculptureScale, this.sculptureScale, this.sculptureScale);
        const nChunks = this.mergeMeshes ? Math.max(1, this.chunks) : 0;
        for (const d of level.cubes) {
            const c: ICube = { key: this.key(d.x, d.y, d.z), x: d.x, y: d.y, z: d.z, color: d.c, local: this.localPos(d.x, d.y, d.z), node: null, chunk: nChunks ? this.chunkOfY(d.y) : -1, reserved: false, removed: false };
            this.cubes.set(c.key, c);
            if (!this.mergeMeshes) c.node = this.makeCubeNode(c);
        }
        if (startHidden) {
            this.revealY = this.minY - 1;
            this.spinning = false;
        }
        if (this.mergeMeshes) this.buildChunks(nChunks);
        this.bindTouch();
    }

    public warmCubeMaterial(): void {
        if (!this.cubeMesh || !this.cubeMaterial) return;
        BeeBuzzing_MaterialWarmup.warmMesh(this, this.node, this.cubeMesh, (mr) => this.tint().apply(mr, 0));
    }

    public hideAll(): void {
        this.spinning = false;
        this.revealY = 1e9;
        this.setRevealLevel(this.minY - 1);
    }

    public setRevealLevel(level: number): void {
        const y = Math.max(this.minY - 1, Math.min(this.maxY + this.introGrowRows + 1, level));
        if (y === this.revealY) return;
        this.revealY = y;
        if (this.mergeMeshes) {
            this.pushRevealUniform();
            return;
        }
        for (const c of this.cubes.values()) {
            if (!c.node) continue;
            const k = this.revealScale(c);
            c.node.active = k > 0;
            c.node.setScale(this.meshScale * k, this.meshScale * k, this.meshScale * k);
        }
    }

    public playIntro(duration: number, onDone?: () => void): void {
        this.hideAll();
        const span = this.maxY - this.minY + 1 + this.introGrowRows;
        const obj = { t: 0 };
        tween(obj).to(Math.max(0.01, duration), { t: 1 }, { onUpdate: () => this.setRevealLevel(this.minY + obj.t * span) })
            .call(() => {
                this.setRevealLevel(this.maxY + this.introGrowRows + 1);
                this.spinning = true;
                if (onDone) onDone();
            })
            .start();
    }

    public materialFor(color: number): Material {
        return this.tint().materialFor(color);
    }

    public cubeList(): IterableIterator<ICube> {
        return this.cubes.values();
    }

    public localPos(x: number, y: number, z: number): Vec3 {
        return new Vec3(this.origin.x + x * this.cell, this.origin.y + y * this.cell, this.origin.z + z * this.cell);
    }

    public worldPos(c: ICube, out: Vec3 = new Vec3()): Vec3 {
        return Vec3.transformMat4(out, c.local, this.node.worldMatrix);
    }

    public worldDir(dx: number, dy: number, dz: number): Vec3 {
        return Vec3.transformQuat(new Vec3(), new Vec3(dx, dy, dz), this.node.worldRotation);
    }

    public hasColor(color: number): boolean {
        for (const c of this.cubes.values()) if (c.color === color && !c.reserved) return true;
        return false;
    }

    public inside(x: number, y: number, z: number): boolean {
        return x >= 0 && y >= 0 && z >= 0 && x < this.size.x && y < this.size.y && z < this.size.z;
    }

    public occupied(x: number, y: number, z: number): boolean {
        return this.inside(x, y, z) && this.cubes.has(this.key(x, y, z));
    }

    public openFaces(c: ICube): number {
        let n = 0;
        for (const d of DIRS) if (!this.occupied(c.x + d[0], c.y + d[1], c.z + d[2])) n++;
        return n;
    }

    public escapeDir(c: ICube): IEscape | null {
        return this.pathFinder.escapeDir(c);
    }

    public findTarget(color: number): ITarget | null {
        return this.pathFinder.findTarget(color);
    }

    public detach(c: ICube): Node {
        if (!c.node) {
            c.node = this.makeCubeNode(c);
            this.markDirty(c);
        }
        return c.node;
    }

    public restore(c: ICube): void {
        if (c.removed) return;
        if (c.node) {
            c.node.destroy();
            c.node = null;
            this.markDirty(c);
        }
        c.reserved = false;
    }

    public take(c: ICube): Node {
        this.cubes.delete(c.key);
        c.removed = true;
        if (this.hideBuried) {
            for (const d of DIRS) {
                const n = this.cubes.get(this.key(c.x + d[0], c.y + d[1], c.z + d[2]));
                if (n) this.markDirty(n);
            }
        }
        return this.detach(c);
    }

    protected onDestroy(): void {
        this.touchUI?.off(Node.EventType.TOUCH_START, this.onDown, this);
        this.touchUI?.off(Node.EventType.TOUCH_MOVE, this.onMove, this);
        this.touchUI?.off(Node.EventType.TOUCH_END, this.onUp, this);
        this.touchUI?.off(Node.EventType.TOUCH_CANCEL, this.onUp, this);
    }

    protected update(dt: number): void {
        if (this.isDragging || !this.spinning) return;
        const k = Math.min(1, dt * 4);
        this.velX = math.lerp(this.velX, (this.spinRightToLeft ? -this.idleSpin : this.idleSpin) * dt, k);
        this.velY = math.lerp(this.velY, 0, k);
        this.spin(this.velX, this.velY);
    }

    protected lateUpdate(): void {
        if (this.mergeMeshes) this.rebuildDirty(false);
    }

    protected onDown(): void {
        ScreenService.Instance().firstClick();

        this.dragging = true;
        this.armed = false;
    }

    protected onMove(e: EventTouch): void {
        if (!this.dragging) return;
        if (!this.armed) {
            const st = e.getStartLocation(), cur = e.getLocation();
            if ((cur.x - st.x) ** 2 + (cur.y - st.y) ** 2 < DRAG_DEAD_ZONE_SQ) return;
            this.armed = true;
            this.velX = 0;
            this.velY = 0;
        }
        this.velX = e.getDeltaX() * this.dragSpeed;
        this.velY = -e.getDeltaY() * this.dragSpeed;
        this.spin(this.velX, this.velY);
    }

    protected onUp(): void {
        this.dragging = false;
        this.armed = false;
    }

    private bindTouch(): void {
        this.touchUI?.on(Node.EventType.TOUCH_START, this.onDown, this);
        this.touchUI?.on(Node.EventType.TOUCH_MOVE, this.onMove, this);
        this.touchUI?.on(Node.EventType.TOUCH_END, this.onUp, this);
        this.touchUI?.on(Node.EventType.TOUCH_CANCEL, this.onUp, this);
    }

    private measureBounds(level: ILevelData): void {
        let minX = 1e9, minY = 1e9, minZ = 1e9, maxX = -1e9, maxY = -1e9, maxZ = -1e9;
        for (const d of level.cubes) {
            minX = Math.min(minX, d.x); maxX = Math.max(maxX, d.x);
            minY = Math.min(minY, d.y); maxY = Math.max(maxY, d.y);
            minZ = Math.min(minZ, d.z); maxZ = Math.max(maxZ, d.z);
        }
        this.minY = minY;
        this.maxY = maxY;
        this.extentY = (maxY - minY + 1) * this.cell;
        const ex = (maxX - minX + 1) * this.cell / 2, ey = this.extentY / 2, ez = (maxZ - minZ + 1) * this.cell / 2;
        this.boundRadius = Math.sqrt(ex * ex + ey * ey + ez * ez);
        this.origin.set(-(minX + maxX) * this.cell / 2, -(minY + maxY) * this.cell / 2, -(minZ + maxZ) * this.cell / 2);
    }

    private buildChunks(count: number): void {
        this.chunkMesh = new BeeBuzzing_ChunkMesh(this.cubeMesh!);
        this.chunkMaterial = new Material();
        this.chunkMaterial.copy(this.cubeMaterial!, { defines: { USE_VERTEX_COLOR: true, USE_INSTANCED_TINT: false, USE_REVEAL: true } } as any);
        this.pushRevealUniform();
        for (let i = 0; i < count; i++) {
            const n = new Node('Chunk' + i);
            n.layer = BeeBuzzing_Config.LAYER_3D;
            n.setParent(this.node);
            const mr = n.addComponent(MeshRenderer);
            mr.shadowCastingMode = MeshRenderer.ShadowCastingMode.OFF;
            mr.receiveShadow = MeshRenderer.ShadowReceivingMode.OFF;
            this.chunkNodes.push(n);
            this.rebuildBudget.add();
        }
        this.rebuildDirty(true);
    }

    private tint(): BeeBuzzing_Tint {
        if (!this.tinted) this.tinted = new BeeBuzzing_Tint(this.cubeMaterial!);
        return this.tinted;
    }

    private key(x: number, y: number, z: number): number {
        return (x * 64 + y) * 64 + z;
    }

    private chunkOfY(y: number): number {
        const n = Math.max(1, this.chunks);
        return Math.min(n - 1, Math.max(0, Math.floor((y - this.minY) / (this.maxY - this.minY + 1) * n)));
    }

    private markDirty(c: ICube): void {
        this.rebuildBudget.mark(c.chunk);
    }

    private pushRevealUniform(): void {
        if (!this.chunkMaterial) return;
        const grow = Math.max(0.001, this.introGrowRows);
        this.chunkMaterial.setProperty('revealParams', new Vec4(this.origin.y + this.revealY * this.cell, grow * this.cell, 0, 0));
    }

    private revealScale(c: ICube): number {
        const t = (this.revealY - c.y) / Math.max(0.001, this.introGrowRows);
        if (t <= 0) return 0;
        if (t >= 1) return 1;
        return t * t * (3 - 2 * t);
    }

    private makeCubeNode(c: ICube): Node {
        const n = new Node('c' + c.x + '_' + c.y + '_' + c.z);
        n.layer = BeeBuzzing_Config.LAYER_3D;
        n.setParent(this.node);
        n.setPosition(c.local);
        n.setScale(this.meshScale, this.meshScale, this.meshScale);
        const mr = n.addComponent(MeshRenderer);
        mr.mesh = this.cubeMesh;
        mr.shadowCastingMode = MeshRenderer.ShadowCastingMode.OFF;
        mr.receiveShadow = MeshRenderer.ShadowReceivingMode.OFF;
        this.tint().apply(mr, c.color);
        return n;
    }

    private rebuildChunk(i: number): void {
        const list: ICube[] = [];
        for (const c of this.cubes.values()) {
            if (c.chunk === i && !c.node && !(this.hideBuried && this.openFaces(c) === 0)) list.push(c);
        }
        this.chunkMesh!.rebuild(i, list, this.chunkNodes[i].getComponent(MeshRenderer)!, this.chunkMaterial!, this.meshScale);
    }

    private rebuildDirty(all: boolean): void {
        if (all) {
            this.rebuildBudget.flushAll((i) => this.rebuildChunk(i));
            return;
        }
        this.rebuildBudget.flushBudgeted(this.maxRebuildsPerFrame, (i) => this.rebuildChunk(i));
    }

    private spin(yawDeg: number, pitchDeg: number): void {
        const d2r = Math.PI / 180;
        if (yawDeg) Quat.rotateAround(this.rot, this.rot, Vec3.UP, yawDeg * d2r);
        if (pitchDeg) Quat.rotateAround(this.rot, this.rot, Vec3.RIGHT, pitchDeg * d2r);
        Quat.normalize(this.rot, this.rot);
        this.node.setRotation(this.rot);
        this.node.setScale(this.sculptureScale, this.sculptureScale, this.sculptureScale);
    }
}
