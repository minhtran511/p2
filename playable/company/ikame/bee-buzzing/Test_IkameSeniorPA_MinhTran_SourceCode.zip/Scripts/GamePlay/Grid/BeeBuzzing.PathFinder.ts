import { Camera, Quat, Vec3 } from 'cc';
import { BeeBuzzing_Config } from '../../Common/BeeBuzzing.Config';
import { BeeBuzzing_VisitStamp } from '../Optimize/BeeBuzzing.VisitStamp';
import { ICube, IEscape, ITarget } from './BeeBuzzing.GridTypes';

export interface IPathGrid {
    readonly camera: Camera | null;
    readonly gridSize: { x: number; y: number; z: number };
    readonly maxTurns: number;
    readonly maxPathSteps: number;
    readonly pathCandidates: number;
    readonly center: Vec3;
    cubeList(): IterableIterator<ICube>;
    inside(x: number, y: number, z: number): boolean;
    occupied(x: number, y: number, z: number): boolean;
    openFaces(c: ICube): number;
    worldDir(dx: number, dy: number, dz: number): Vec3;
    worldPos(c: ICube, out: Vec3): Vec3;
}

interface ICandidate {
    cube: ICube;
    front: number;
    open: number;
    z: number;
    y: number;
    x: number;
}

type TStep = [number, number, number, number, number, number];

const DIRS = BeeBuzzing_Config.DIRS;
const tmpV = new Vec3();

export class BeeBuzzing_PathFinder {
    private readonly visited: BeeBuzzing_VisitStamp = new BeeBuzzing_VisitStamp();

    constructor(private readonly grid: IPathGrid) {}

    public escapeDir(c: ICube): IEscape | null {
        const g = this.grid;
        if (!g.camera) return null;
        const toCam = Vec3.subtract(new Vec3(), g.camera.node.worldPosition, g.center).normalize();
        const size = g.gridSize;
        this.visited.begin(size.x * size.y * size.z * 6);
        const q: TStep[] = [];
        for (let d = 0; d < 6; d++) q.push([c.x, c.y, c.z, d, 0, 0]);
        let best: Vec3 | null = null;
        let bestDot = 0.15;
        let bestSteps = 1e9;
        let head = 0;
        while (head < q.length) {
            const s = q[head++];
            const x = s[0], y = s[1], z = s[2], d = s[3], t = s[4], steps = s[5];
            if (steps > g.maxPathSteps) break;
            if (best && steps > bestSteps) break;
            const nx = x + DIRS[d][0], ny = y + DIRS[d][1], nz = z + DIRS[d][2];
            if (!g.inside(nx, ny, nz)) {
                const wd = g.worldDir(DIRS[d][0], DIRS[d][1], DIRS[d][2]);
                const dot = Vec3.dot(wd, toCam);
                if (dot > 0.15 && (steps < bestSteps || (steps === bestSteps && dot > bestDot))) { bestDot = dot; best = wd; bestSteps = steps; }
                continue;
            }
            if (g.occupied(nx, ny, nz)) continue;
            const vk = (((nx * size.y) + ny) * size.z + nz) * 6 + d;
            if (!this.visited.visit(vk)) continue;
            q.push([nx, ny, nz, d, t, steps + 1]);
            if (t < g.maxTurns) {
                for (let nd = 0; nd < 6; nd++) {
                    if (nd === d || (nd ^ 1) === d) continue;
                    q.push([nx, ny, nz, nd, t + 1, steps + 1]);
                }
            }
        }
        return best ? { dir: best, steps: bestSteps } : null;
    }

    public findTarget(color: number): ITarget | null {
        const g = this.grid;
        if (!g.camera) return null;
        const camNode = g.camera.node;
        const inv = Quat.invert(new Quat(), camNode.worldRotation);
        const toCam = Vec3.subtract(new Vec3(), camNode.worldPosition, g.center).normalize();
        const cands: ICandidate[] = [];
        for (const c of g.cubeList()) {
            if (c.color !== color || c.reserved) continue;
            const open = g.openFaces(c);
            if (!open) continue;
            let front = -1;
            for (const d of DIRS) {
                if (g.occupied(c.x + d[0], c.y + d[1], c.z + d[2])) continue;
                const dot = Vec3.dot(g.worldDir(d[0], d[1], d[2]), toCam);
                if (dot > front) front = dot;
            }
            g.worldPos(c, tmpV);
            const wy = tmpV.y;
            Vec3.subtract(tmpV, tmpV, camNode.worldPosition);
            Vec3.transformQuat(tmpV, tmpV, inv);
            cands.push({ cube: c, front, open, z: tmpV.z, y: wy, x: tmpV.x });
        }
        const bucket = (f: number): number => (f > 0.7 ? 2 : f > 0.25 ? 1 : 0);
        cands.sort((a, b) => (bucket(b.front) - bucket(a.front)) || (b.open - a.open) || (b.z - a.z) || (b.y - a.y) || (b.x - a.x));
        let best: { cube: ICube; exit: Vec3; steps: number } | null = null;
        const n = Math.min(cands.length, g.pathCandidates);
        for (let i = 0; i < n; i++) {
            const r = this.escapeDir(cands[i].cube);
            if (!r) continue;
            if (!best || r.steps < best.steps) best = { cube: cands[i].cube, exit: r.dir, steps: r.steps };
            if (best.steps === 0) break;
        }
        if (best) return { cube: best.cube, exit: best.exit };
        for (let i = n; i < cands.length; i++) {
            const r = this.escapeDir(cands[i].cube);
            if (r) return { cube: cands[i].cube, exit: r.dir };
        }
        return null;
    }
}
