import { _decorator, Component, Node, Vec3, Quat } from 'cc';
import { EBeeState, IFlightOpts } from './BeeBuzzing.BeeTypes';
import { BeeBuzzing_Bezier } from './BeeBuzzing.Bezier';
import { BeeBuzzing_BeeAxes } from './BeeBuzzing.BeeAxes';
import { Injection } from 'db://assets/Scripts/Core/Base/Module/Handler/Module.Dependency';
import { BeeBuzzing_PlayableConfig } from '../../../BeeBuzzing.PlayableConfig';
import { EModuleService } from 'db://assets/Scripts/Core/Base/Module/Common/Module.Enum';
import { BeeBuzzing_Audio, EBeeBuzzing_SFX } from '../../Systems/BeeBuzzing.Audio';
import { BeeBuzzing_PopThrottle } from '../Optimize/BeeBuzzing.PopThrottle';
const { ccclass } = _decorator;

const TO_SCREEN = new Vec3(0, 0.25, 1).normalize();
const FACE_UP = new Vec3(0, 1, 0.2);
const DEEP = new Vec3(0, 0.1, -1).normalize();
const HOLE_ENTRY = new Vec3(0, 1, -0.25).normalize();
const POP_CLIPS: EBeeBuzzing_SFX[] = [EBeeBuzzing_SFX.POP_CUBE, EBeeBuzzing_SFX.BEE_END];

@ccclass('BeeBuzzing_Bee')
export class BeeBuzzing_Bee extends Component {

    @Injection(BeeBuzzing_PlayableConfig.code, EModuleService.Audio)
    private _audio: BeeBuzzing_Audio = null;

    private readonly axes: BeeBuzzing_BeeAxes = new BeeBuzzing_BeeAxes();
    private readonly wings: Node[] = [];
    private readonly targetRot: Quat = new Quat();
    private readonly tmp: Vec3 = new Vec3();
    private readonly tmpQ: Quat = new Quat();
    private readonly turnSpeed: number = 12;
    private flap: number = 0;

    private st: EBeeState = EBeeState.Idle;
    private o: IFlightOpts | null = null;
    private cube: Node | null = null;
    private speed: number = 1;
    private vMax: number = 6;
    private home: (() => Vec3) | null = null;
    private onGrab: (() => void) | null = null;
    private onDone: (() => void) | null = null;

    private readonly p0: Vec3 = new Vec3();
    private readonly p1: Vec3 = new Vec3();
    private readonly p2: Vec3 = new Vec3();
    private readonly p3: Vec3 = new Vec3();
    private readonly prev: Vec3 = new Vec3();
    private ct: number = 0;
    private cdur: number = 1;

    private timer: number = 0;
    private lift: number = 0;
    private scaleT: number = 0;
    private sideSign: number = 1;
    private orbitAng: number = 0;
    private readonly orbitPt: Vec3 = new Vec3();
    private readonly liftLocal: Vec3 = new Vec3();

    protected onLoad(): void {
        this.wings.length = 0;
        this.node.walk((n) => { if (/wing/i.test(n.name)) this.wings.push(n); });
        this.axes.readFrom(this.node);
    }

    protected onEnable(): void {
        this.node.setRotationFromEuler(0, 0, 0);
        Quat.copy(this.targetRot, this.node.worldRotation);
        this.st = EBeeState.Idle;
    }

    protected onDisable(): void {
        this.st = EBeeState.Idle;
        this.cube = null;
    }

    public fly(cube: Node, speed: number, home: () => Vec3, o: IFlightOpts, onGrab: () => void, onDone: () => void): void {
        this.o = o;
        this.cube = cube;
        this.speed = speed;
        this.vMax = o.flySpeed * speed;
        this.home = home;
        this.onGrab = onGrab;
        this.onDone = onDone;
        this.lift = 0;
        this.timer = 0;
        this.scaleT = 0;
        this.sideSign = o.launchSide < 0 ? -1 : o.launchSide > 0 ? 1 : (Math.random() < 0.5 ? -1 : 1);
        this.headTo(o.hiveForward, true);
        this.st = EBeeState.Exit;
        this.startCurve();
    }

    private playPop(): void {
        if (!this._audio || !BeeBuzzing_PopThrottle.tryPlay()) return;
        this._audio.playOneShotSFX(POP_CLIPS[Math.floor(Math.random() * POP_CLIPS.length)]);
    }


    protected update(dt: number): void {
        this.animate(dt);
        const o = this.o;
        if (!o || this.st === EBeeState.Idle) return;
        this.updateScale(o, dt);
        switch (this.st) {
            case EBeeState.Curve: this.updateCurve(o, dt); break;
            case EBeeState.Orbit: this.updateOrbit(o, dt); break;
            case EBeeState.Settle: this.updateSettle(o, dt); break;
            case EBeeState.Hold: this.updateHold(o, dt); break;
            case EBeeState.Lift: this.updateLift(o, dt); break;
            case EBeeState.Home: this.updateHome(dt); break;
        }
    }

    private animate(dt: number): void {
        this.flap += dt * 70;
        const a = Math.sin(this.flap) * 38;
        for (const w of this.wings) w.setRotationFromEuler(0, 0, w.name.includes('L') ? a : -a);
        Quat.slerp(this.tmpQ, this.node.worldRotation, this.targetRot, Math.min(1, dt * this.turnSpeed));
        this.node.setWorldRotation(this.tmpQ);
    }

    private updateScale(o: IFlightOpts, dt: number): void {
        if (o.scaleTime <= 0 || this.scaleT >= o.scaleTime) return;
        this.scaleT += dt;
        const e = BeeBuzzing_Bezier.smoothstep(this.scaleT / o.scaleTime);
        const s = o.scaleFrom + (o.scaleTo - o.scaleFrom) * e;
        this.node.setScale(s, s, s);
    }

    private updateCurve(o: IFlightOpts, dt: number): void {
        if (o.isDragging()) { this.startOrbit(); return; }
        if (this.stepCurve(dt)) this.st = EBeeState.Settle;
    }

    private updateOrbit(o: IFlightOpts, dt: number): void {
        this.orbitAng += dt * 1.6;
        const axis = Vec3.subtract(new Vec3(), this.orbitPt, o.sculptCenter).normalize();
        const tang = Vec3.cross(new Vec3(), axis, Vec3.UP);
        if (tang.lengthSqr() < 1e-4) tang.set(1, 0, 0);
        tang.normalize();
        const wob = Vec3.scaleAndAdd(new Vec3(), this.orbitPt, tang, Math.sin(this.orbitAng) * 0.6);
        wob.y += Math.cos(this.orbitAng * 0.7) * 0.4;
        const toPt = Vec3.subtract(new Vec3(), wob, this.node.worldPosition);
        const d = toPt.length();
        if (d > 1e-3) {
            const step = Math.min(d, this.vMax * 0.8 * dt);
            this.headTo(toPt);
            this.node.setWorldPosition(Vec3.scaleAndAdd(this.tmp, this.node.worldPosition, toPt.normalize(), step));
        }
        if (o.isDragging()) { this.timer = 0; return; }
        if (this.timer <= 0) this.timer = 0.05 + Math.random() * 0.45;
        this.timer -= dt;
        if (this.timer > 0) return;
        if (o.retarget) {
            const n = o.retarget();
            if (n) this.cube = n;
        }
        this.startCurve();
    }

    private updateSettle(o: IFlightOpts, dt: number): void {
        const exit = o.exitWorld();
        const rest = Vec3.scaleAndAdd(new Vec3(), o.cubeWorld(), exit, this.bellyGap());
        this.bellyTo(exit);
        const to = Vec3.subtract(new Vec3(), rest, this.node.worldPosition);
        const d = to.length();
        if (d > 1e-3) this.node.setWorldPosition(Vec3.scaleAndAdd(this.tmp, this.node.worldPosition, to.multiplyScalar(1 / d), Math.min(d, this.vMax * 0.7 * dt)));
        if (d < 0.03) {
            this.st = EBeeState.Hold;
            this.timer = o.holdTime / this.speed;
        }
    }

    private updateHold(o: IFlightOpts, dt: number): void {
        const exit = o.exitWorld();
        const rest = Vec3.scaleAndAdd(new Vec3(), o.cubeWorld(), exit, this.bellyGap());
        rest.x += (Math.random() - 0.5) * 0.015;
        rest.y += (Math.random() - 0.5) * 0.015;
        this.node.setWorldPosition(rest);
        this.bellyTo(exit);
        this.timer -= dt;
        if (this.timer > 0) return;
        this.grab(o, rest);
    }

    private grab(o: IFlightOpts, rest: Vec3): void {
        const cube = this.cube!;
        const wp = cube.worldPosition.clone(), ws = cube.worldScale.clone(), wr = cube.worldRotation.clone();
        cube.setParent(this.node, false);
        cube.setWorldPosition(wp);
        cube.setWorldScale(ws);
        cube.setWorldRotation(wr);
        if (this.onGrab) this.onGrab();
        this.playPop();
        this.liftLocal.set(o.toLocal(rest));
        this.lift = -0.06;
        this.st = EBeeState.Lift;
    }

    private updateLift(o: IFlightOpts, dt: number): void {
        const exit = o.exitWorld();
        const rest = o.toWorld(this.liftLocal);
        this.lift += dt * (this.lift < 0 ? 1.2 : 4.5) * this.speed;
        this.node.setWorldPosition(Vec3.scaleAndAdd(this.tmp, rest, exit, Math.max(-0.05, this.lift)));
        this.bellyTo(exit);
        if (this.lift >= 1.1) this.startHome();
    }

    private updateHome(dt: number): void {
        const done = this.stepCurve(dt);
        this.headTo(Vec3.subtract(this.tmp, this.p3, this.node.worldPosition));
        if (!done) return;
        this.st = EBeeState.Idle;
        if (this.onDone) this.onDone();
    }

    private startCurve(): void {
        const o = this.o!;
        const from = this.node.worldPosition.clone();
        const exit = o.exitWorld();
        const hover = Vec3.scaleAndAdd(new Vec3(), o.cubeWorld(), exit, 1.0 + o.tailLen);
        const dist = Vec3.distance(hover, from);
        const side = new Vec3(this.sideSign, 0, 0);
        const swing = Math.min(0.55 * dist + 1.1, o.sculptRadius + 2.4) * o.swingScale;
        const lane = Vec3.multiplyScalar(new Vec3(), o.jitter, 0.35);
        const cont = this.st === EBeeState.Exit ? o.hiveForward.clone() : Vec3.subtract(new Vec3(), this.node.worldPosition, this.prev).normalize();
        if (cont.lengthSqr() < 1e-4) cont.set(0, 1, 0);
        const p1 = Vec3.scaleAndAdd(new Vec3(), from, cont, 0.4 * dist + o.tailLen * 2.0);
        Vec3.scaleAndAdd(p1, p1, side, swing * 0.08);
        p1.add(lane);
        const p2 = Vec3.scaleAndAdd(new Vec3(), hover, DEEP, 0.6 + 0.2 * dist);
        Vec3.scaleAndAdd(p2, p2, side, swing * 0.95);
        p2.add(lane);
        BeeBuzzing_Bezier.keepOutside(p2, o.sculptCenter, o.sculptRadius, o.avoidMargin + 0.3);
        const top = Math.max(from.y, hover.y);
        p1.y = Math.max(p1.y, from.y + 0.35 * Math.max(0, hover.y - from.y));
        p2.y = Math.max(p2.y, top + 0.4);
        BeeBuzzing_Bezier.bendAroundSphere(from, p1, p2, hover, o.sculptCenter, o.sculptRadius, o.avoidMargin, true, false);
        this.setCurve(from, p1, p2, hover);
        this.st = EBeeState.Curve;
    }

    private startHome(): void {
        const o = this.o!;
        const from = this.node.worldPosition.clone();
        const dest = this.home!();
        const dir = Vec3.subtract(new Vec3(), dest, from);
        const horiz = Vec3.cross(new Vec3(), dir, Vec3.UP);
        if (horiz.lengthSqr() < 1e-4) horiz.set(1, 0, 0);
        horiz.normalize().multiplyScalar(Math.random() < 0.5 ? 1 : -1);
        const swing = 0.35 * dir.length() + 0.7;
        const q1 = Vec3.scaleAndAdd(new Vec3(), from, horiz, swing);
        q1.y += 1.2;
        q1.add(o.jitter);
        const q2 = Vec3.scaleAndAdd(new Vec3(), dest, HOLE_ENTRY, -1.6);
        BeeBuzzing_Bezier.keepOutside(q1, o.sculptCenter, o.sculptRadius, o.avoidMargin + 0.3);
        BeeBuzzing_Bezier.bendAroundSphere(from, q1, q2, dest, o.sculptCenter, o.sculptRadius, o.avoidMargin, false, true);
        this.setCurve(from, q1, q2, dest);
        this.st = EBeeState.Home;
    }

    private startOrbit(): void {
        const o = this.o!;
        const d = new Vec3(this.sideSign * (0.75 + Math.random() * 0.25), Math.random() * 0.35, 0.15 + Math.random() * 0.45).normalize();
        Vec3.scaleAndAdd(this.orbitPt, o.sculptCenter, d, o.sculptRadius + o.orbitPad);
        this.orbitAng = Math.random() * Math.PI * 2;
        this.st = EBeeState.Orbit;
    }

    private setCurve(p0: Vec3, p1: Vec3, p2: Vec3, p3: Vec3, minDur: number = 0.3, maxDur: number = 2.6): void {
        this.p0.set(p0); this.p1.set(p1); this.p2.set(p2); this.p3.set(p3);
        this.cdur = Math.min(maxDur, Math.max(minDur, BeeBuzzing_Bezier.lengthOfCurve(p0, p1, p2, p3) / Math.max(0.1, this.vMax)));
        this.ct = 0;
        this.prev.set(p0);
    }

    private stepCurve(dt: number): boolean {
        this.ct = Math.min(1, this.ct + dt / this.cdur);
        const e = BeeBuzzing_Bezier.smoothstep(this.ct);
        const pos = BeeBuzzing_Bezier.cubic(new Vec3(), this.p0, this.p1, this.p2, this.p3, e);
        pos.y += Math.sin(e * Math.PI * 5) * 0.02 * Math.sin(e * Math.PI);
        const vel = Vec3.subtract(new Vec3(), pos, this.prev);
        if (vel.lengthSqr() > 1e-8) this.headTo(vel);
        this.prev.set(pos);
        this.node.setWorldPosition(pos);
        return this.ct >= 1;
    }

    private headTo(dir: Vec3, snap: boolean = false): void {
        if (dir.lengthSqr() < 1e-6) return;
        this.axes.orient(dir, TO_SCREEN, this.targetRot);
        if (snap) this.node.setWorldRotation(this.targetRot);
    }

    private bellyTo(exit: Vec3): void {
        const headDir = Vec3.scaleAndAdd(new Vec3(), FACE_UP, exit, -Vec3.dot(FACE_UP, exit));
        if (headDir.lengthSqr() < 1e-5) headDir.set(0, 0, 1);
        this.axes.orient(headDir.normalize(), exit, this.targetRot);
    }

    private bellyGap(): number {
        return (this.o ? this.o.cubeHalf : 0.1) + this.axes.bellyOut * this.node.worldScale.x;
    }
}
