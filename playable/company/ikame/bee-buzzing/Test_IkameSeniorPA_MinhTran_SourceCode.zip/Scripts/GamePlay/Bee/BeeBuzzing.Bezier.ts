import { Vec3 } from 'cc';

export class BeeBuzzing_Bezier {
    public static cubic(out: Vec3, p0: Vec3, p1: Vec3, p2: Vec3, p3: Vec3, t: number): Vec3 {
        const u = 1 - t, uu = u * u, tt = t * t;
        out.x = uu * u * p0.x + 3 * uu * t * p1.x + 3 * u * tt * p2.x + tt * t * p3.x;
        out.y = uu * u * p0.y + 3 * uu * t * p1.y + 3 * u * tt * p2.y + tt * t * p3.y;
        out.z = uu * u * p0.z + 3 * uu * t * p1.z + 3 * u * tt * p2.z + tt * t * p3.z;
        return out;
    }

    public static lengthOfCurve(p0: Vec3, p1: Vec3, p2: Vec3, p3: Vec3): number {
        const a = new Vec3(), b = p0.clone();
        let len = 0;
        for (let i = 1; i <= 16; i++) {
            BeeBuzzing_Bezier.cubic(a, p0, p1, p2, p3, i / 16);
            len += Vec3.distance(a, b);
            b.set(a);
        }
        return len;
    }

    public static smoothstep(t: number): number {
        const k = Math.max(0, Math.min(1, t));
        return k * k * (3 - 2 * k);
    }

    public static keepOutside(p: Vec3, center: Vec3, radius: number, margin: number = 0.7): Vec3 {
        const d = Vec3.subtract(new Vec3(), p, center);
        const len = d.length();
        if (len < radius + margin) {
            if (len < 1e-4) d.set(0, 1, 0); else d.multiplyScalar(1 / len);
            Vec3.scaleAndAdd(p, center, d, radius + margin);
        }
        return p;
    }

    public static bendAroundSphere(p0: Vec3, p1: Vec3, p2: Vec3, p3: Vec3, center: Vec3, radius: number, margin: number = 0.7, lockP1: boolean = false, lockP2: boolean = false): void {
        const s = new Vec3();
        for (let pass = 0; pass < 3; pass++) {
            let worst = 0, worstT = 0;
            for (let i = 1; i < 12; i++) {
                const t = i / 12;
                BeeBuzzing_Bezier.cubic(s, p0, p1, p2, p3, t);
                const pen = radius + margin - Vec3.distance(s, center);
                if (pen > worst) { worst = pen; worstT = t; }
            }
            if (worst <= 0.02) break;
            const target = (worstT < 0.5 && !lockP1) || lockP2 ? p1 : p2;
            const d = Vec3.subtract(new Vec3(), target, center);
            if (d.lengthSqr() < 1e-6) d.set(0, 1, 0);
            if (d.y < 0) d.y = 0;
            if (d.lengthSqr() < 1e-6) d.set(0, 1, 0);
            d.normalize();
            Vec3.scaleAndAdd(target, target, d, worst * 1.6);
        }
    }
}
