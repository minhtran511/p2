import { Mat3, Node, Quat, Vec3 } from 'cc';

export class BeeBuzzing_BeeAxes {
    private static readonly BELLY_PAD: number = 0.02;

    public readonly head: Vec3 = new Vec3(0, 0, 1);
    public readonly back: Vec3 = new Vec3(0, 1, 0);
    public bellyOut: number = 0.25;

    public readFrom(root: Node): void {
        let head: Node | null = null, tail: Node | null = null, belly: Node | null = null;
        root.walk((n) => {
            if (/^head$/i.test(n.name)) head = n;
            if (/^tail$/i.test(n.name)) tail = n;
            if (/^belly$/i.test(n.name)) belly = n;
        });
        if (!head || !tail) return;
        Vec3.subtract(this.head, (head as Node).position, (tail as Node).position).normalize();
        if (!belly) return;
        const mid = Vec3.add(new Vec3(), (head as Node).position, (tail as Node).position).multiplyScalar(0.5);
        const b = Vec3.subtract(new Vec3(), (belly as Node).position, mid);
        Vec3.scaleAndAdd(b, b, this.head, -Vec3.dot(b, this.head));
        if (b.lengthSqr() < 1e-6) return;
        this.bellyOut = b.length() + BeeBuzzing_BeeAxes.BELLY_PAD;
        Vec3.negate(this.back, b.normalize());
    }

    public orient(headDir: Vec3, backDir: Vec3, out: Quat): Quat {
        const zw = headDir.clone().normalize();
        const yw = Vec3.scaleAndAdd(new Vec3(), backDir, zw, -Vec3.dot(backDir, zw));
        if (yw.lengthSqr() < 1e-5) yw.set(Math.abs(zw.y) < 0.9 ? 0 : 1, Math.abs(zw.y) < 0.9 ? 1 : 0, 0);
        yw.normalize();
        const xw = Vec3.cross(new Vec3(), yw, zw).normalize();
        const xl = Vec3.cross(new Vec3(), this.back, this.head).normalize();
        const world = new Mat3(xw.x, xw.y, xw.z, yw.x, yw.y, yw.z, zw.x, zw.y, zw.z);
        const localT = new Mat3(xl.x, this.back.x, this.head.x, xl.y, this.back.y, this.head.y, xl.z, this.back.z, this.head.z);
        const m = new Mat3();
        Mat3.multiply(m, world, localT);
        Quat.fromMat3(out, m);
        return Quat.normalize(out, out);
    }
}
