import { Node, Vec3 } from 'cc';

export interface IFlightOpts {
    jitter: Vec3;
    tailLen: number;
    flySpeed: number;
    holdTime: number;
    hiveForward: Vec3;
    sculptCenter: Vec3;
    sculptRadius: number;
    cubeHalf: number;
    launchSide: number;
    scaleFrom: number;
    scaleTo: number;
    scaleTime: number;
    orbitPad: number;
    avoidMargin: number;
    swingScale: number;
    cubeWorld: () => Vec3;
    exitWorld: () => Vec3;
    isDragging: () => boolean;
    toLocal: (p: Vec3) => Vec3;
    toWorld: (p: Vec3) => Vec3;
    retarget?: () => Node | null | undefined;
}

export enum EBeeState {
    Idle, 
    Exit, 
    Curve, 
    Settle, 
    Hold, 
    Lift, 
    Home, 
    Orbit
}
