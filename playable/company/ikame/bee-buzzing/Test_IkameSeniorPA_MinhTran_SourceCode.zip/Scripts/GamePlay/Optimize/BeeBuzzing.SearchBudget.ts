const SEARCHES_PER_FRAME = 2;

export class BeeBuzzing_SearchBudget {
    private used: number = 0;

    constructor(private readonly perFrame: number = SEARCHES_PER_FRAME) {}

    public reset(): void {
        this.used = 0;
    }

    public tryConsume(): boolean {
        if (this.used >= this.perFrame) return false;
        this.used++;
        return true;
    }
}
