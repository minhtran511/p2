export class BeeBuzzing_RebuildBudget {
    private readonly dirty: boolean[] = [];
    private cursor: number = 0;

    public get size(): number {
        return this.dirty.length;
    }

    public add(): void {
        this.dirty.push(true);
    }

    public mark(chunk: number): void {
        if (chunk >= 0) this.dirty[chunk] = true;
    }

    public flushAll(rebuild: (chunk: number) => void): void {
        for (let i = 0; i < this.dirty.length; i++) {
            if (this.dirty[i]) {
                rebuild(i);
                this.dirty[i] = false;
            }
        }
    }

    public flushBudgeted(maxPerFrame: number, rebuild: (chunk: number) => void): void {
        const n = this.dirty.length;
        let budget = Math.max(1, maxPerFrame);
        for (let k = 0; k < n && budget > 0; k++) {
            const i = (this.cursor + k) % n;
            if (!this.dirty[i]) continue;
            rebuild(i);
            this.dirty[i] = false;
            this.cursor = i + 1;
            budget--;
        }
    }
}
