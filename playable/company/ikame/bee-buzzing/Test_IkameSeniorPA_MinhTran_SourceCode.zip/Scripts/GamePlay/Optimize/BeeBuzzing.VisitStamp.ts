export class BeeBuzzing_VisitStamp {
    private cells: Uint16Array | null = null;
    private stamp: number = 0;

    public begin(size: number): void {
        if (!this.cells || this.cells.length < size) this.cells = new Uint16Array(size);
        this.stamp++;
        if (this.stamp === 65535) {
            this.cells.fill(0);
            this.stamp = 1;
        }
    }

    public visit(index: number): boolean {
        const cells = this.cells!;
        if (cells[index] === this.stamp) return false;
        cells[index] = this.stamp;
        return true;
    }
}
