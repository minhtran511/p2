const POP_MIN_GAP_MS = 160;

export class BeeBuzzing_PopThrottle {
    private static lastAt: number = 0;

    public static tryPlay(): boolean {
        const now = performance.now();
        if (now - BeeBuzzing_PopThrottle.lastAt < POP_MIN_GAP_MS) return false;
        BeeBuzzing_PopThrottle.lastAt = now;
        return true;
    }
}
