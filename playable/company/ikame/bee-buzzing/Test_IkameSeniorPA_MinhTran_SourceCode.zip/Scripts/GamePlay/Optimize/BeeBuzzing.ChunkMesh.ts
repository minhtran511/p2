import { gfx, Mesh, MeshRenderer, Material, utils } from 'cc';
import { BeeBuzzing_Data } from '../../Common/BeeBuzzing.Data';
import { ICube } from '../Grid/BeeBuzzing.GridTypes';

interface IScratch {
    pos: Float32Array;
    nrm: Float32Array;
    col: Float32Array;
    idx: Uint32Array;
    cen: Float32Array;
}

export class BeeBuzzing_ChunkMesh {
    private readonly pos: Float32Array;
    private readonly nrm: Float32Array;
    private readonly idx: Uint16Array | Uint32Array;
    private readonly vCount: number;
    private readonly scratch: (IScratch | null)[] = [];

    constructor(cubeMesh: Mesh) {
        this.pos = cubeMesh.readAttribute(0, gfx.AttributeName.ATTR_POSITION) as Float32Array;
        this.nrm = cubeMesh.readAttribute(0, gfx.AttributeName.ATTR_NORMAL) as Float32Array;
        this.idx = cubeMesh.readIndices(0) as Uint16Array;
        this.vCount = this.pos.length / 3;
    }

    public rebuild(chunk: number, list: ICube[], mr: MeshRenderer, material: Material, meshScale: number): void {
        const old = mr.mesh;
        if (!list.length) {
            mr.mesh = null;
            if (old) old.destroy();
            return;
        }
        const sc = this.buffers(chunk, list.length);
        const posLen = list.length * this.pos.length;
        const positions = sc.pos.subarray(0, posLen) as unknown as number[];
        const normals = sc.nrm.subarray(0, posLen) as unknown as number[];
        const centers = sc.cen.subarray(0, posLen) as unknown as number[];
        const colors = sc.col.subarray(0, list.length * this.vCount * 4) as unknown as number[];
        const indices = sc.idx.subarray(0, list.length * this.idx.length) as unknown as number[];
        for (let k = 0; k < list.length; k++) {
            const c = list[k];
            const col = BeeBuzzing_Data.colorOf(c.color);
            const r = col.r / 255, g = col.g / 255, b = col.b / 255;
            const pBase = k * this.pos.length, cBase = k * this.vCount * 4, iBase = k * this.idx.length;
            for (let v = 0; v < this.vCount; v++) {
                const p = pBase + v * 3;
                positions[p] = this.pos[v * 3] * meshScale + c.local.x;
                positions[p + 1] = this.pos[v * 3 + 1] * meshScale + c.local.y;
                positions[p + 2] = this.pos[v * 3 + 2] * meshScale + c.local.z;
                centers[p] = c.local.x; centers[p + 1] = c.local.y; centers[p + 2] = c.local.z;
                normals[p] = this.nrm[v * 3]; normals[p + 1] = this.nrm[v * 3 + 1]; normals[p + 2] = this.nrm[v * 3 + 2];
                const q = cBase + v * 4;
                colors[q] = r; colors[q + 1] = g; colors[q + 2] = b; colors[q + 3] = 1;
            }
            for (let t = 0; t < this.idx.length; t++) indices[iBase + t] = this.idx[t] + k * this.vCount;
        }
        mr.mesh = utils.MeshUtils.createMesh({
            positions, normals, colors, indices, primitiveMode: gfx.PrimitiveMode.TRIANGLE_LIST,
            customAttributes: [{ attr: new gfx.Attribute('a_center', gfx.Format.RGB32F), values: centers }],
        });
        mr.setSharedMaterial(material, 0);
        if (old) old.destroy();
    }

    private buffers(chunk: number, count: number): IScratch {
        let sc = this.scratch[chunk];
        if (sc && sc.pos.length >= count * this.pos.length && sc.idx.length >= count * this.idx.length) return sc;
        const cap = Math.ceil(count * 1.25) + 8;
        sc = {
            pos: new Float32Array(cap * this.pos.length),
            nrm: new Float32Array(cap * this.nrm.length),
            col: new Float32Array(cap * this.vCount * 4),
            idx: new Uint32Array(cap * this.idx.length),
            cen: new Float32Array(cap * this.pos.length),
        };
        this.scratch[chunk] = sc;
        return sc;
    }
}
