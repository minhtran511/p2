import { instantiate, Material, MeshRenderer, Node, Prefab } from 'cc';
import { BeeBuzzing_Config } from '../../Common/BeeBuzzing.Config';
import { BeeBuzzing_Tint } from '../Render/BeeBuzzing.Tint';

export interface IBeeMetrics {
    scale: number;
    tail: number;
}

export class BeeBuzzing_BeePool {
    private readonly pool: Node[] = [];
    private readonly materials = new Map<Material, Material>();
    private bodyTint: BeeBuzzing_Tint | null = null;

    constructor(private readonly prefab: Prefab, private readonly root: Node) {}

    public acquire(): Node {
        let bee = this.pool.pop();
        if (!bee) bee = this.create();
        bee.setParent(this.root);
        bee.active = true;
        return bee;
    }

    public release(bee: Node): void {
        bee.active = false;
        this.pool.push(bee);
    }

    public tintBody(bee: Node, color: number): void {
        const body = bee.getComponentsInChildren(MeshRenderer).find((m) => m.node.name === 'Body');
        if (!body) return;
        if (!this.bodyTint) this.bodyTint = new BeeBuzzing_Tint(body.sharedMaterials[0]!);
        this.bodyTint.apply(body, color, 0);
    }

    public measure(bee: Node, bodyLength: number): IBeeMetrics {
        const mr = bee.getComponentInChildren(MeshRenderer);
        if (!mr || !mr.model || !mr.model.modelBounds) return { scale: 1, tail: 0.3 };
        const h = mr.model.modelBounds.halfExtents;
        const ext = Math.max(h.x, h.y, h.z);
        const scale = bodyLength / (ext * 2);
        return { scale, tail: ext * scale * 0.95 };
    }

    private create(): Node {
        const bee = instantiate(this.prefab);
        bee.walk((n) => { n.layer = BeeBuzzing_Config.LAYER_3D; });
        for (const mr of bee.getComponentsInChildren(MeshRenderer)) {
            mr.shadowCastingMode = MeshRenderer.ShadowCastingMode.OFF;
            mr.receiveShadow = MeshRenderer.ShadowReceivingMode.OFF;
            for (let i = 0; i < mr.sharedMaterials.length; i++) {
                const src = mr.sharedMaterials[i];
                if (!src) continue;
                mr.setSharedMaterial(this.instanced(src), i);
            }
        }
        return bee;
    }

    private instanced(src: Material): Material {
        let m = this.materials.get(src);
        if (!m) {
            m = new Material();
            m.copy(src, { defines: { USE_INSTANCING: true } } as any);
            this.materials.set(src, m);
        }
        return m;
    }
}
