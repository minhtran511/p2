import { Component, Mesh, MeshRenderer, Node } from 'cc';
import { BeeBuzzing_Config } from '../../Common/BeeBuzzing.Config';

export class BeeBuzzing_MaterialWarmup {
    public static warmMesh(host: Component, parent: Node, mesh: Mesh, apply: (mr: MeshRenderer) => void, lifetime: number = 0.15): void {
        const n = new Node('warm');
        n.layer = BeeBuzzing_Config.LAYER_3D;
        n.setParent(parent);
        n.setScale(0.001, 0.001, 0.001);
        const mr = n.addComponent(MeshRenderer);
        mr.mesh = mesh;
        mr.shadowCastingMode = MeshRenderer.ShadowCastingMode.OFF;
        mr.receiveShadow = MeshRenderer.ShadowReceivingMode.OFF;
        apply(mr);
        host.scheduleOnce(() => n.destroy(), lifetime);
    }
}
