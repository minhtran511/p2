import { Material, MeshRenderer } from 'cc';
import { BeeBuzzing_Data } from '../../Common/BeeBuzzing.Data';

export function supportsInstancedTint(m: Material | null): boolean {
    if (!m) return false;
    for (const p of m.passes) if (p.defines && (p.defines as any).USE_INSTANCED_TINT) return true;
    return false;
}

export class BeeBuzzing_Tint {
    private readonly perColor: Map<number, Material> = new Map<number, Material>();
    private shared: Material | null = null;
    private sharedTransparent: Material | null = null;

    constructor(private readonly base: Material) {}

    public get usesAttribute(): boolean {
        return supportsInstancedTint(this.base);
    }

    public materialFor(color: number, transparent: boolean = false): Material {
        if (this.usesAttribute) return transparent ? this.transparentMaterial() : this.opaqueMaterial();
        let m = this.perColor.get(color);
        if (!m) {
            m = this.clone({ USE_INSTANCING: true });
            try { m.setProperty('mainColor', BeeBuzzing_Data.linearColorOf(color)); } catch (e) { }
            this.perColor.set(color, m);
        }
        return m;
    }

    public apply(mr: MeshRenderer, color: number, slot: number = 0, opacity: number = 1): void {
        mr.setSharedMaterial(this.materialFor(color, opacity < 0.999), slot);
        if (!this.usesAttribute) return;
        const c = BeeBuzzing_Data.colorOf(color);
        mr.setInstancedAttribute('a_tint', [c.r, c.g, c.b, Math.round(255 * Math.max(0, Math.min(1, opacity)))]);
    }

    private opaqueMaterial(): Material {
        if (!this.shared) this.shared = this.clone({ USE_INSTANCING: true });
        return this.shared;
    }

    private transparentMaterial(): Material {
        if (!this.sharedTransparent) this.sharedTransparent = this.clone({ USE_INSTANCING: true }, 1);
        return this.sharedTransparent;
    }

    private clone(defines: Record<string, boolean>, technique?: number): Material {
        const m = new Material();
        m.copy(this.base, (technique === undefined ? { defines } : { technique, defines }) as any);
        return m;
    }
}
