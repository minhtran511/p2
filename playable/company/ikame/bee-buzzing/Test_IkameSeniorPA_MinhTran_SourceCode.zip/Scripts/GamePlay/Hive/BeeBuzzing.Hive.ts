import { _decorator, Component, Node, MeshRenderer, Label, Vec3, Color, tween } from 'cc';
import { BeeBuzzing_Tint } from '../Render/BeeBuzzing.Tint';
import { BeeBuzzing_Config } from '../../Common/BeeBuzzing.Config';
const { ccclass, property } = _decorator;

const tmpV = new Vec3();
const tmpOff = new Vec3();

export enum EHiveState { Queue, Moving, Active, Done }

interface IHiveBounds {
    ext: number;
    depth: number;
    center: Vec3;
}

@ccclass('BeeBuzzing_Hive')
export class BeeBuzzing_Hive extends Component {
    private static bounds: IHiveBounds | null = null;

    @property(Node)
    public model: Node | null = null;

    @property(Label)
    public ammoLabel: Label | null = null;

    @property({ tooltip: 'Digit height relative to the hive width' })
    public labelScale: number = 0.4;

    @property({ tooltip: 'Label offset from the hive centre, relative to the hive width' })
    public labelOffsetY: number = -0.04;

    public color: number = 0;
    public ammo: number = 0;
    public line: number = 0;
    public index: number = 0;
    public state: EHiveState = EHiveState.Queue;
    public slot: number = -1;
    public size: number = 1;

    private readonly modelCenter: Vec3 = new Vec3();
    private modelExt: number = 1;
    private modelDepth: number = 0.3;
    private tint: BeeBuzzing_Tint | null = null;
    private mr: MeshRenderer | null = null;
    private opacity: number = 1;
    private punching: boolean = false;

    protected onEnable(): void {
        if (this.mr && this.tint) this.tint.apply(this.mr, this.color, 0, this.opacity);
    }

    public prepare(color: number, tint: BeeBuzzing_Tint | null): void {
        this.color = color;
        this.node.walk((n) => { n.layer = BeeBuzzing_Config.LAYER_3D; });
        this.tint = tint;
        this.mr = this.model ? this.model.getComponentInChildren(MeshRenderer) : null;
        if (this.mr) {
            this.mr.shadowCastingMode = MeshRenderer.ShadowCastingMode.OFF;
            this.mr.receiveShadow = MeshRenderer.ShadowReceivingMode.OFF;
            if (tint) tint.apply(this.mr, color, 0, this.opacity);
        }
        if (this.ammoLabel) this.ammoLabel.cacheMode = Label.CacheMode.CHAR;
    }

    public init(color: number, ammo: number, line: number, index: number, tint: BeeBuzzing_Tint | null, size: number, labelRoot: Node | null): void {
        this.ammo = ammo;
        this.line = line;
        this.index = index;
        if (this.color !== color || !this.mr) this.prepare(color, tint);
        this.readBounds();
        if (this.ammoLabel && labelRoot) {
            this.ammoLabel.node.layer = BeeBuzzing_Config.LAYER_3D;
            this.ammoLabel.node.setParent(labelRoot, false);
        }
        this.setSize(size);
        this.refreshLabel();
    }

    public setOpacity(a: number): void {
        if (a === this.opacity) return;
        this.opacity = a;
        if (this.mr && this.tint) this.tint.apply(this.mr, this.color, 0, a);
        if (this.ammoLabel) this.ammoLabel.color = new Color(255, 255, 255, Math.round(255 * a));
    }

    public setSize(size: number): void {
        this.size = size;
        const s = size / this.modelExt;
        if (this.model) {
            this.model.setScale(s, s, s);
            this.model.setPosition(-this.modelCenter.x * s, -this.modelCenter.y * s, -this.modelCenter.z * s);
        }
        this.syncLabel();
    }

    public syncLabel(): void {
        if (!this.ammoLabel) return;
        const n = this.ammoLabel.node;
        const show = this.node.activeInHierarchy && this.ammo > 0 && this.state !== EHiveState.Done;
        if (n.active !== show) n.active = show;
        if (!show) return;
        const s = this.size / this.modelExt;
        const k = this.size * this.labelScale / this.ammoLabel.fontSize;
        tmpOff.set(0, this.size * this.labelOffsetY, this.modelDepth * s * 0.5 + 0.02);
        Vec3.transformQuat(tmpV, tmpOff, this.node.worldRotation);
        const wp = this.node.worldPosition;
        n.setWorldPosition(wp.x + tmpV.x, wp.y + tmpV.y, wp.z + tmpV.z);
        n.setWorldScale(k * this.node.worldScale.x, k * this.node.worldScale.y, k);
    }

    public refreshLabel(): void {
        if (this.ammoLabel) this.ammoLabel.string = String(this.ammo);
    }

    public consume(): boolean {
        if (this.ammo <= 0) return false;
        this.ammo--;
        this.refreshLabel();
        return true;
    }

    public hopTo(target: Vec3, duration: number, onDone?: () => void, endScale: number = 1, bounce: boolean = false): void {
        this.state = EHiveState.Moving;
        const start = this.node.worldPosition.clone();
        const s0 = this.node.scale.x;
        const obj = { t: 0 };
        tween(obj).to(duration, { t: 1 }, {
            easing: 'quadInOut',
            onUpdate: () => {
                const p = new Vec3();
                Vec3.lerp(p, start, target, obj.t);
                p.y += Math.sin(obj.t * Math.PI) * this.size * 0.8;
                this.node.setWorldPosition(p);
                const k = s0 + (endScale - s0) * obj.t;
                const squash = Math.sin(obj.t * Math.PI) * 0.12;
                this.node.setScale(k * (1 + squash), k * (1 - squash), k * (1 + squash));
            },
        }).call(() => {
            this.node.setWorldPosition(target);
            if (bounce) {
                this.landBounce(target, endScale, onDone);
                return;
            }
            this.node.setScale(endScale, endScale, endScale);
            if (onDone) onDone();
        }).start();
    }

    public leave(onDone: () => void): void {
        this.state = EHiveState.Done;
        if (this.ammoLabel) this.ammoLabel.node.active = false;
        const e = this.node.eulerAngles.clone();
        tween(this.node)
            .to(0.5, { eulerAngles: new Vec3(e.x, e.y, e.z + 540), scale: new Vec3(0, 0, 0) }, { easing: 'quadIn' })
            .call(() => {
                if (this.ammoLabel) this.ammoLabel.node.destroy();
                this.node.destroy();
                onDone();
            })
            .start();
    }

    public punch(): void {
        if (this.state === EHiveState.Moving || this.punching) return;
        this.punching = true;
        const s = this.node.scale.x;
        const bounce = tween().to(0.07, { scale: new Vec3(s * 0.88, s * 1.12, s * 0.88) }).to(0.12, { scale: new Vec3(s, s, s) });
        tween(this.node)
            .repeat(2, bounce)
            .call(() => { this.punching = false; this.node.setScale(s, s, s); })
            .start();
    }

    private readBounds(): void {
        const mr = this.mr;
        if (!mr) return;
        if (!BeeBuzzing_Hive.bounds && mr.model && mr.model.modelBounds) {
            const bb = mr.model.modelBounds;
            BeeBuzzing_Hive.bounds = { ext: Math.max(bb.halfExtents.x, bb.halfExtents.y) * 2, depth: bb.halfExtents.z * 2, center: bb.center.clone() };
        }
        const b = BeeBuzzing_Hive.bounds;
        if (!b) return;
        this.modelExt = b.ext;
        this.modelDepth = b.depth;
        this.modelCenter.set(b.center);
    }

    private landBounce(target: Vec3, k: number, onDone?: () => void): void {
        const up1 = target.clone();
        up1.y += this.size * 0.38;
        const up2 = target.clone();
        up2.y += this.size * 0.14;
        this.node.setScale(k * 1.22, k * 0.72, k * 1.22);
        tween(this.node)
            .to(0.1, { worldPosition: up1, scale: new Vec3(k * 0.94, k * 1.1, k * 0.94) }, { easing: 'quadOut' })
            .to(0.1, { worldPosition: target, scale: new Vec3(k * 1.12, k * 0.84, k * 1.12) }, { easing: 'quadIn' })
            .to(0.08, { worldPosition: up2, scale: new Vec3(k * 0.97, k * 1.04, k * 0.97) }, { easing: 'quadOut' })
            .to(0.08, { worldPosition: target, scale: new Vec3(k * 1.05, k * 0.94, k * 1.05) }, { easing: 'quadIn' })
            .to(0.09, { scale: new Vec3(k, k, k) })
            .call(() => { this.node.setWorldPosition(target); if (onDone) onDone(); })
            .start();
    }
}
