import { _decorator, Component, Node, Camera, Vec3, UITransform, sp, tween } from 'cc';
import { BeeBuzzing_Event, EBeeBuzzing_Event } from '../../Common/BeeBuzzing.Event';
const { ccclass, property } = _decorator;

enum EGuideStep { None, TapHive, SpeedButton, Done }

@ccclass('BeeBuzzing_Guide')
export class BeeBuzzing_Guide extends Component {
    @property({ type: Node, tooltip: "Spine hand (child of Guide)" })
    public hand: Node | null = null;

    @property({ type: Camera, tooltip: "Camera3D Overlay - used to project the 3D hive onto the canvas" })
    public camera3D: Camera | null = null;

    @property({ type: Camera, tooltip: "Camera 2D UI" })
    public uiCamera: Camera | null = null;

    @property({ type: Node, tooltip: "X2 speed button - second hint points at it" })
    public speedButton: Node | null = null;

    @property({ type: Node, tooltip: "Download button - hidden until the second hint" })
    public downloadButton: Node | null = null;

    @property({ tooltip: "Spine animation played while the hand points" })
    public tapAnimation: string = 'tap';

    @property({ tooltip: "Seconds of play (after the first tap) before the X2 hint and the download button appear" })
    public secondHintDelay: number = 10;

    @property({ tooltip: "Hand offset from the target, canvas px (the finger tip is the hand's pivot)" })
    public handOffset: Vec3 = new Vec3(40, -40, 0);

    private step: EGuideStep = EGuideStep.None;
    private skeleton: sp.Skeleton | null = null;
    private target3D: Node | null = null;
    private targetNode: Node | null = null;
    private mirrored: boolean = false;
    private speedUsed: boolean = false;

    protected onLoad(): void {
        this.skeleton = this.hand ? this.hand.getComponent(sp.Skeleton) : null;
        BeeBuzzing_Event.on(EBeeBuzzing_Event.INTRO_DONE, this.onIntroDone, this);
        BeeBuzzing_Event.on(EBeeBuzzing_Event.GAME_STARTED, this.onGameStarted, this);
        BeeBuzzing_Event.on(EBeeBuzzing_Event.SPEED_CHANGED, this.onSpeedChanged, this);
        BeeBuzzing_Event.on(EBeeBuzzing_Event.WIN, this.onGameOver, this);
        BeeBuzzing_Event.on(EBeeBuzzing_Event.LOSE, this.onGameOver, this);
    }

    protected start(): void {
        if (this.hand) this.hand.active = false;
        if (this.downloadButton) this.downloadButton.active = false;
    }

    protected onDestroy(): void {
        BeeBuzzing_Event.targetOff(this);
    }

    protected lateUpdate(): void {
        if (!this.hand || !this.hand.active) return;
        if (this.targetNode) this.moveHand(this.targetNode.worldPosition);
        else if (this.target3D && this.target3D.isValid) this.moveHand(this.projectToUI(this.target3D.worldPosition));
    }

    protected onIntroDone(hive?: Node): void {
        if (this.step !== EGuideStep.None || !hive) return;
        this.step = EGuideStep.TapHive;
        this.pointAt3D(hive);
    }

    protected onGameStarted(): void {
        if (this.step === EGuideStep.TapHive) this.hideHand();
        this.scheduleOnce(() => this.showSecondHint(), this.secondHintDelay);
    }

    protected onSpeedChanged(): void {
        this.speedUsed = true;
        if (this.step === EGuideStep.SpeedButton) this.finish();
    }

    protected onGameOver(): void {
        this.unscheduleAllCallbacks();
        this.finish();
    }

    private showSecondHint(): void {
        if (this.step === EGuideStep.Done) return;
        this.revealDownload();
        if (this.speedUsed || !this.speedButton) {
            this.finish();
            return;
        }
        this.step = EGuideStep.SpeedButton;
        this.pointAtUI(this.speedButton, true);
    }

    private revealDownload(): void {
        const btn = this.downloadButton;
        if (!btn || btn.active) return;
        const target = btn.scale.clone();
        btn.setScale(0, 0, 1);
        btn.active = true;
        tween(btn).to(0.35, { scale: target }, { easing: 'backOut' }).start();
    }

    private finish(): void {
        this.step = EGuideStep.Done;
        this.hideHand();
    }

    private pointAt3D(target: Node): void {
        this.target3D = target;
        this.targetNode = null;
        this.mirrored = false;
        this.showHand(this.projectToUI(target.worldPosition));
    }

    private pointAtUI(target: Node, mirror: boolean = false): void {
        this.targetNode = target;
        this.target3D = null;
        this.mirrored = mirror;
        this.showHand(target.worldPosition);
    }

    private projectToUI(worldPos: Vec3): Vec3 {
        if (!this.camera3D || !this.uiCamera) return worldPos;
        const screen = this.camera3D.worldToScreen(worldPos);
        return this.uiCamera.screenToWorld(new Vec3(screen.x, screen.y, 0));
    }

    private showHand(uiWorld: Vec3): void {
        if (!this.hand) return;
        this.moveHand(uiWorld);
        this.hand.active = true;
        if (this.skeleton) this.skeleton.setAnimation(0, this.tapAnimation, true);
    }

    private moveHand(uiWorld: Vec3): void {
        const hand = this.hand!;
        const tf = this.node.getComponent(UITransform)!;
        const local = tf.convertToNodeSpaceAR(uiWorld);
        const dir = this.mirrored ? -1 : 1;
        hand.setPosition(local.x + this.handOffset.x * dir, local.y + this.handOffset.y, 0);
        const sx = Math.abs(hand.scale.x) * dir;
        if (hand.scale.x !== sx) hand.setScale(sx, hand.scale.y, hand.scale.z);
    }

    private hideHand(): void {
        this.targetNode = null;
        this.target3D = null;
        if (this.hand) this.hand.active = false;
    }
}
