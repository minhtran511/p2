import { _decorator, Camera, Canvas, Component, screen, view } from 'cc';
const { ccclass, property, requireComponent } = _decorator;

@ccclass('BeeBuzzing_CanvasCameraSync')
@requireComponent(Canvas)
export class BeeBuzzing_CanvasCameraSync extends Component {
    @property({ type: [Camera], tooltip: "Extra 2D cameras that render this canvas (e.g. Camera 2D Overlay). cc.Canvas only resizes its own cameraComponent; these get the same orthoHeight, near/far and position on every resize." })
    public cameras: Camera[] = [];

    private canvas: Canvas | null = null;

    protected onLoad(): void {
        this.canvas = this.getComponent(Canvas);
    }

    protected onEnable(): void {
        view.on('canvas-resize', this.onResize, this);
        view.on('design-resolution-changed', this.onResize, this);
        screen.on('window-resize', this.onResize, this);
        this.sync();
    }

    protected onDisable(): void {
        view.off('canvas-resize', this.onResize, this);
        view.off('design-resolution-changed', this.onResize, this);
        screen.off('window-resize', this.onResize, this);
    }

    protected lateUpdate(): void {
        this.sync();
    }

    protected onResize(): void {
        this.sync();
    }

    private sync(): void {
        const src = this.canvas ? this.canvas.cameraComponent : null;
        if (!src) return;
        const pos = src.node.worldPosition;
        for (const dst of this.cameras) {
            if (!dst || dst === src || !dst.isValid) continue;
            if (dst.projection !== src.projection) dst.projection = src.projection;
            if (dst.orthoHeight !== src.orthoHeight) dst.orthoHeight = src.orthoHeight;
            if (dst.near !== src.near) dst.near = src.near;
            if (dst.far !== src.far) dst.far = src.far;
            if (!dst.node.worldPosition.equals(pos)) dst.node.setWorldPosition(pos);
        }
    }
}
