import { _decorator, Component, Node, Label, tween, Vec3, EventTouch, Sprite } from 'cc';
import { PlayableController } from 'db://assets/Scripts/Core/Base/Playable/Playable.Controller';
import { BeeBuzzing_Event, EBeeBuzzing_Event } from '../../Common/BeeBuzzing.Event';
const { ccclass, property } = _decorator;

@ccclass('BeeBuzzing_UI')
export class BeeBuzzing_UI extends Component {
    @property({ type: Label, tooltip: "Shows the % of cubes collected (0% -> 100%)" })
    public progressLabel: Label | null = null;

    @property(Label)
    public speedLabel: Label | null = null;

    @property(Node)
    public hint: Node | null = null;

    @property(Node)
    public endPanel: Node | null = null;

    @property(Label)
    public endTitle: Label | null = null;

    @property({ tooltip: 'Open the store automatically when the level ends (after this many seconds; <0 = never).' })
    public autoCtaDelay: number = 2;

    private x2: boolean = false;

    protected onLoad(): void {
        BeeBuzzing_Event.on(EBeeBuzzing_Event.PROGRESS, this.onProgress, this);
        BeeBuzzing_Event.on(EBeeBuzzing_Event.GAME_STARTED, this.onGameStarted, this);
        BeeBuzzing_Event.on(EBeeBuzzing_Event.WIN, this.onWin, this);
        BeeBuzzing_Event.on(EBeeBuzzing_Event.LOSE, this.onLose, this);
    }

    protected onDestroy(): void {
        BeeBuzzing_Event.targetOff(this);
    }

    protected start(): void {
        if (this.endPanel) this.endPanel.active = false;
        if (this.hint) tween(this.hint).repeatForever(tween().to(0.5, { scale: new Vec3(1.08, 1.08, 1) }).to(0.5, { scale: new Vec3(1, 1, 1) })).start();
    }

    protected onProgress(done: number, total: number): void {
        if (this.progressLabel && total > 0) this.progressLabel.string = Math.round(done / total * 100) + '%';
    }

    protected onGameStarted(): void {
        if (this.hint && this.hint.active) this.hint.active = false;
    }

    protected onWin(): void {
        this.showEnd(true);
    }

    protected onLose(): void {
        this.showEnd(false);
    }

    protected onSpeedClick(event: EventTouch): void {
        const sprite = event.currentTarget.getComponent(Sprite);
        if (sprite) sprite.grayscale = !sprite.grayscale;
        this.x2 = !this.x2;
        BeeBuzzing_Event.emit(EBeeBuzzing_Event.SPEED_CHANGED, this.x2);
    }

    protected onCtaClick(): void {
        PlayableController.Instance().CTA();
    }

    protected onOpenStore(): void {
        PlayableController.Instance().openStore();
    }

    private showEnd(win: boolean): void {
        if (this.endTitle) this.endTitle.string = win ? 'VICTORY' : 'FAIL';
        if (this.endPanel) {
            this.endPanel.active = true;
            this.endPanel.setScale(0.6, 0.6, 1);
            tween(this.endPanel).to(0.4, { scale: new Vec3(1, 1, 1) }, { easing: 'backOut' }).start();
        }
        const pc = PlayableController.TryGetInstance();
        if (pc) pc.endGame();
        if (this.autoCtaDelay >= 0) this.scheduleOnce(() => this.onCtaClick(), this.autoCtaDelay);
    }
}
