import { _decorator, Component, Node } from 'cc';
import { ModuleBaseComponent } from 'db://assets/Scripts/Core/Base/Module/Module.BaseComponent';
import { BeeBuzzing_PlayableConfig } from 'db://assets/Modules/BeeBuzzing/BeeBuzzing.PlayableConfig';

const { ccclass, property } = _decorator;

@ccclass('BeeBuzzing_Module')
export class BeeBuzzing_Module extends ModuleBaseComponent {

    protected moduleId: string = BeeBuzzing_PlayableConfig.code;
}