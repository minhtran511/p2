import { _decorator, Component, Node } from 'cc';
import { ILanguageServiceModule, LanguageServiceModule } from 'db://assets/Scripts/Core/Base/Services/Language/Language.ServiceModule';

const { ccclass, property } = _decorator;

@ccclass('BeeBuzzing_Language')
export class BeeBuzzing_Language extends LanguageServiceModule implements ILanguageServiceModule {

}