import { _decorator, Component, Node } from 'cc';
import { IScreenServiceModule, ScreenServiceModule } from 'db://assets/Scripts/Core/Base/Services/Screen/Screen.ServiceModule';

const { ccclass, property } = _decorator;

@ccclass('BeeBuzzing_Screen')
export class BeeBuzzing_Screen extends ScreenServiceModule implements IScreenServiceModule {

}