
import { i18n } from "db://assets/Scripts/Core/Base/Services/Language/Handler/Language.i18n";
import { ELanguage } from "db://assets/Scripts/Core/Base/Services/Language/Common/Language.Enum";
import { BeeBuzzing_PlayableConfig } from "db://assets/Modules/BeeBuzzing/BeeBuzzing.PlayableConfig";

const bundleCode: string = BeeBuzzing_PlayableConfig.code;
const language: string = ELanguage.ENGLISH;

const schema = {

}

i18n.registerLanguage(bundleCode, language, schema); 