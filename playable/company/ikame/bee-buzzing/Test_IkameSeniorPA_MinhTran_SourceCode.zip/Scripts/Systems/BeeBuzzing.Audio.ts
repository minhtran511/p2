import { _decorator, Component, Node } from 'cc';
import { AudioServiceModule, IAudioServiceModule } from 'db://assets/Scripts/Core/Base/Services/Audio/Audio.ServiceModule';
const { ccclass, property } = _decorator;

export enum EBeeBuzzing_SFX {
    BEE1,
    BEE2,
    BEE3,
    BEE_END, //ong chui vao to
    CLICK,
    FAIL,
    POP_CUBE,
    SHOW_ENDCARD,
    VICTORY
};

export enum EBeeBuzzing_Music {
    BG_MUSIC
};

@ccclass('BeeBuzzing_Audio')
export class BeeBuzzing_Audio extends AudioServiceModule implements IAudioServiceModule  {

    protected onLoad(): void {
        this.initialize(EBeeBuzzing_SFX, EBeeBuzzing_Music);

        this.setVolume(1);
        this.setClipMusic(EBeeBuzzing_Music.BG_MUSIC);
        this.setLoopingMusic(true);

        this.addAudioSourceSFX(EBeeBuzzing_SFX.BEE1, EBeeBuzzing_SFX.BEE1);
        this.addAudioSourceSFX(EBeeBuzzing_SFX.BEE2, EBeeBuzzing_SFX.BEE2);
        this.addAudioSourceSFX(EBeeBuzzing_SFX.BEE3, EBeeBuzzing_SFX.BEE3);
    }
}