import { Layers } from 'cc';

/** Static configuration for the BeeBuzzing module (scene tunables live on BeeBuzzing_Controller in the inspector). */
export class BeeBuzzing_Config {
    /** Layer rendered by "Camera3D Overlay" (drawn on top of the 2D canvas). */
    public static readonly LAYER_3D: number = Layers.Enum.UI_3D;

    /** Directions of the 6 cube faces. */
    public static readonly DIRS: [number, number, number][] = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];

    /** BoxyBlast palette (GameColor id -> hex). Ids 14 & 17 are unused in the source data. */
    public static readonly PALETTE: Record<number, string> = {
        0: '#7A1428', 1: '#CC3333', 2: '#D47F7F', 3: '#8B2255', 4: '#CC2288', 5: '#FF55AA',
        6: '#FF88CC', 7: '#441888', 8: '#8844BB', 9: '#6644FF', 10: '#AA88EE', 11: '#11205A',
        12: '#1212E6', 13: '#2299EE', 15: '#118866', 16: '#19D4E6', 18: '#147914', 19: '#778833',
        20: '#0FBE0F', 21: '#DD9900', 22: '#FFDD00', 23: '#EE7722', 24: '#FFAA77', 25: '#442211',
        26: '#85351B', 27: '#BB8833', 28: '#313131', 29: '#EEEEEE', 30: '#6C6C7B',
    };
}
