import { Color, Vec4 } from 'cc';
import { BeeBuzzing_Config } from './BeeBuzzing.Config';

// ---------------------------------------------------------------------------------------------
// Raw level file (Resources/LevelData/*.json, exported from the BoxyBlast editor)
// ---------------------------------------------------------------------------------------------
export interface IRawCube { GridPosition: { x: number; y: number; z: number }; Color: number; Health: number; }
export interface IRawShooter { Color: number; Ammo: number; Line: number; Index: number; }
export interface IRawLevel {
    GridSize: { x: number; y: number; z: number };
    CellSize: number;
    LineCount: number;
    Cubes: IRawCube[];
    ShooterSpawnData: IRawShooter[];
}

// ---------------------------------------------------------------------------------------------
// Parsed level used by the game
// ---------------------------------------------------------------------------------------------
export interface ICubeData { x: number; y: number; z: number; c: number; }
export interface IHiveData { c: number; ammo: number; line: number; index: number; }
export interface ILevelData {
    gridSize: { x: number; y: number; z: number };
    cellSize: number;
    lineCount: number;
    slotCount: number;
    cubes: ICubeData[];
    hives: IHiveData[];
}

export class BeeBuzzing_Data {
    /** Convert the raw editor export into the compact runtime level. */
    public static parseLevel(raw: IRawLevel, slotCount = 5): ILevelData {
        const cubes: ICubeData[] = raw.Cubes.map((c) => ({ x: c.GridPosition.x, y: c.GridPosition.y, z: c.GridPosition.z, c: c.Color }));
        const hives: IHiveData[] = raw.ShooterSpawnData
            .map((s) => ({ c: s.Color, ammo: s.Ammo, line: s.Line, index: s.Index }))
            .sort((a, b) => a.index - b.index || a.line - b.line);
        return { gridSize: raw.GridSize, cellSize: raw.CellSize, lineCount: raw.LineCount, slotCount, cubes, hives };
    }

    private static colorCache = new Map<number, Color>();
    /** Palette colour (sRGB). */
    public static colorOf(id: number): Color {
        let c = this.colorCache.get(id);
        if (!c) { c = new Color().fromHEX(BeeBuzzing_Config.PALETTE[id] ?? '#FF00FF'); this.colorCache.set(id, c); }
        return c;
    }

    /** Palette colour as a linear-space Vec4 for material props declared `linear: true`. */
    public static linearColorOf(id: number, gamma = 1.8): Vec4 {
        const c = this.colorOf(id);
        const f = (v: number) => Math.pow(v / 255, gamma);
        return new Vec4(f(c.r), f(c.g), f(c.b), 1);
    }
}
