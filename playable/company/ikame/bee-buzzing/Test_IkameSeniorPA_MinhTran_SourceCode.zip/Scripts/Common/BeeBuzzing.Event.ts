import { EventTarget } from 'cc';

export enum EBeeBuzzing_Event {
    /** (done: number, total: number) */
    PROGRESS = 'BeeBuzzing.PROGRESS',
    /** everything is built (grid, all hives, materials warmed) - same frame as start(); fade your black overlay from here */
    SETUP_DONE = 'BeeBuzzing.SETUP_DONE',
    /** sculpture fully built (intro finished) */
    INTRO_DONE = 'BeeBuzzing.INTRO_DONE',
    /** first hive tapped */
    GAME_STARTED = 'BeeBuzzing.GAME_STARTED',
    WIN = 'BeeBuzzing.WIN',
    LOSE = 'BeeBuzzing.LOSE',
    /** (x2: boolean) */
    SPEED_CHANGED = 'BeeBuzzing.SPEED_CHANGED',
}

/** Module-local event bus (gameplay -> UI). */
export const BeeBuzzing_Event = new EventTarget();
